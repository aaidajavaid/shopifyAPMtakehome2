/* ============================================================================
 * demo.ts: every piece of editable demo content lives here.
 *
 * Change any name, price, score, line of copy or timing in this file and the
 * app updates. No component needs to be touched.
 *
 * Images: drop a file into public/images/products/ or public/images/closet/
 * with the filename listed below (e.g. blazer.png). Until the file exists the
 * app shows a flat illustrated placeholder in the item's colour.
 * ========================================================================== */

// ─── Occasions ──────────────────────────────────────────────────────────────
// One consistent colour per occasion across the whole app.

export type Occasion = 'Workwear' | 'Smart casual' | 'Casual' | 'After-work' | 'Weekend';

export const occasionColors: Record<Occasion, { bg: string; fg: string }> = {
  Workwear: { bg: '#E4EBF3', fg: '#3D5878' },
  'Smart casual': { bg: '#DFEDEC', fg: '#2F6B69' },
  Casual: { bg: '#E4EEE5', fg: '#4A6E52' },
  'After-work': { bg: '#F4E2E5', fg: '#8C3F53' },
  Weekend: { bg: '#FAEBD4', fg: '#94601A' },
};

// ─── Score colours ──────────────────────────────────────────────────────────
// Rings and scores take the colour of the first band they reach.

export const scoreBands = [
  { min: 70, color: '#3E8A5C', soft: '#E1EFE5', label: 'good' },
  { min: 50, color: '#C08A2E', soft: '#F7ECD8', label: 'okay' },
  { min: 0, color: '#B4533F', soft: '#F6E2DC', label: 'low' },
];

// ─── Placeholder illustrations ─────────────────────────────────────────────
// Used until a real photo exists. `kind` picks the drawing, `color` fills it.

export type PlaceholderKind =
  | 'shirt' | 'blouse' | 'tee' | 'sweater' | 'cardigan' | 'blazer' | 'coat' | 'dress'
  | 'pant' | 'jeans' | 'leggings' | 'skirt'
  | 'flats' | 'sneaker' | 'boot'
  | 'belt' | 'tote' | 'hoops';

export interface Placeholder {
  kind: PlaceholderKind;
  color: string;
  /** Optional second colour (stripes, stitching, soles, buckle). */
  accent?: string;
}

// ─── Merchants ──────────────────────────────────────────────────────────────

export interface Merchant {
  id: string;
  name: string;
  /** "View product" link, opened in a new tab. */
  url: string;
}

export const merchants: Record<string, Merchant> = {
  everlane: { id: 'everlane', name: 'Everlane', url: 'https://www.everlane.com' },
  frankandoak: { id: 'frankandoak', name: 'Frank And Oak', url: 'https://www.frankandoak.com' },
  kotn: { id: 'kotn', name: 'Kotn', url: 'https://kotn.com' },
  stevemadden: {
    id: 'stevemadden',
    name: 'Steve Madden',
    url: 'https://www.stevemadden.ca/products/selma-black-leather',
  },
};

// ─── Closet ─────────────────────────────────────────────────────────────────

export type ClosetCategory = 'tops' | 'bottoms' | 'outerwear' | 'shoes' | 'accessories';

export interface ClosetItem {
  id: string;
  name: string;
  category: ClosetCategory;
  occasions: Occasion[];
  wornInLooks: number;
  /** Ids of other closet items this pairs well with. */
  pairsWith: string[];
  /** Filename in public/images/closet/ */
  image: string;
  placeholder: Placeholder;
}

export const closetItems: ClosetItem[] = [
  {
    id: 'striped-shirt',
    name: 'Striped button-up',
    category: 'tops',
    occasions: ['Workwear', 'Smart casual', 'Weekend'],
    wornInLooks: 9,
    pairsWith: ['dark-jeans', 'midi-skirt', 'trench'],
    image: 'striped-shirt.png',
    placeholder: { kind: 'shirt', color: '#F5F7FB', accent: '#6A86AE' },
  },
  {
    id: 'white-tee',
    name: 'White tee',
    category: 'tops',
    occasions: ['Casual', 'Weekend'],
    wornInLooks: 14,
    pairsWith: ['dark-jeans', 'yoga-pants', 'white-sneakers'],
    image: 'white-tee.png',
    placeholder: { kind: 'tee', color: '#FFFFFF' },
  },
  {
    id: 'cream-knit',
    name: 'Cream knit sweater',
    category: 'tops',
    occasions: ['Casual', 'Weekend'],
    wornInLooks: 7,
    pairsWith: ['dark-jeans', 'midi-skirt', 'ankle-boots'],
    image: 'cream-knit.png',
    placeholder: { kind: 'sweater', color: '#EFE5D3' },
  },
  {
    id: 'slip-dress',
    name: 'Black slip dress',
    category: 'tops',
    occasions: ['After-work', 'Weekend'],
    wornInLooks: 4,
    pairsWith: ['grey-cardigan', 'ankle-boots', 'gold-hoops'],
    image: 'slip-dress.png',
    placeholder: { kind: 'dress', color: '#2A2724' },
  },
  {
    id: 'dark-jeans',
    name: 'Dark-wash jeans',
    category: 'bottoms',
    occasions: ['Casual', 'Weekend'],
    wornInLooks: 16,
    pairsWith: ['white-tee', 'striped-shirt', 'cream-knit'],
    image: 'dark-jeans.png',
    placeholder: { kind: 'jeans', color: '#2E3D57', accent: '#C9A15B' },
  },
  {
    id: 'yoga-pants',
    name: 'Black yoga pants',
    category: 'bottoms',
    occasions: ['Casual'],
    wornInLooks: 11,
    pairsWith: ['white-tee', 'grey-cardigan', 'white-sneakers'],
    image: 'yoga-pants.png',
    placeholder: { kind: 'leggings', color: '#1F1E21' },
  },
  {
    id: 'midi-skirt',
    name: 'Black midi skirt',
    category: 'bottoms',
    occasions: ['Workwear', 'After-work'],
    wornInLooks: 5,
    pairsWith: ['striped-shirt', 'cream-knit', 'ankle-boots'],
    image: 'midi-skirt.png',
    placeholder: { kind: 'skirt', color: '#29262A' },
  },
  {
    id: 'trench',
    name: 'Trench coat',
    category: 'outerwear',
    occasions: ['Workwear', 'Weekend'],
    wornInLooks: 6,
    pairsWith: ['striped-shirt', 'dark-jeans', 'ankle-boots'],
    image: 'trench.png',
    placeholder: { kind: 'coat', color: '#C9B08A', accent: '#A88E66' },
  },
  {
    id: 'grey-cardigan',
    name: 'Grey cardigan',
    category: 'outerwear',
    occasions: ['Casual', 'Workwear'],
    wornInLooks: 8,
    pairsWith: ['white-tee', 'slip-dress', 'yoga-pants'],
    image: 'grey-cardigan.png',
    placeholder: { kind: 'cardigan', color: '#A9A8A6' },
  },
  {
    id: 'white-sneakers',
    name: 'White sneakers',
    category: 'shoes',
    occasions: ['Casual', 'Weekend'],
    wornInLooks: 15,
    pairsWith: ['dark-jeans', 'white-tee', 'yoga-pants'],
    image: 'white-sneakers.png',
    placeholder: { kind: 'sneaker', color: '#F7F6F3', accent: '#D9D4CC' },
  },
  {
    id: 'ankle-boots',
    name: 'Black ankle boots',
    category: 'shoes',
    occasions: ['Workwear', 'After-work'],
    wornInLooks: 7,
    pairsWith: ['midi-skirt', 'dark-jeans', 'slip-dress'],
    image: 'ankle-boots.png',
    placeholder: { kind: 'boot', color: '#232124' },
  },
  {
    id: 'tote',
    name: 'Tan leather tote',
    category: 'accessories',
    occasions: ['Workwear', 'Casual'],
    wornInLooks: 12,
    pairsWith: ['trench', 'striped-shirt', 'dark-jeans'],
    image: 'tote.png',
    placeholder: { kind: 'tote', color: '#A8754F' },
  },
  {
    id: 'gold-hoops',
    name: 'Gold hoops',
    category: 'accessories',
    occasions: ['After-work', 'Weekend'],
    wornInLooks: 10,
    pairsWith: ['slip-dress', 'white-tee', 'cream-knit'],
    image: 'gold-hoops.png',
    placeholder: { kind: 'hoops', color: '#D2AA45' },
  },
];

/** Total closet size used in "goes with X of 13 pieces". */
export const closetSize = closetItems.length;

// ─── Stylist products ───────────────────────────────────────────────────────

export interface Product {
  id: string;
  name: string;
  merchantId: keyof typeof merchants;
  /** CAD */
  price: number;
  occasions: Occasion[];
  /** How many of Jane's closet pieces this goes with. Percent is derived. */
  closetMatches: number;
  /** One-line reason shown on the Confidence Card. */
  reason: string;
  /** Closet item ids shown as "Pairs with" thumbnails. */
  pairsWith: string[];
  socialProof: {
    lines: [string, string];
    quote: { text: string; name: string; role: string };
  };
  /** Filename in public/images/products/ */
  image: string;
  placeholder: Placeholder;
  /** Where the item would sit in the Closet tab. */
  closetSlot: ClosetCategory;
  /** Short name used in compact places (bag, Dress Up label). */
  shortName: string;
}

export const products: Product[] = [
  {
    id: 'blouse',
    name: 'Relaxed Satin Blouse, Ivory',
    shortName: 'Satin Blouse',
    merchantId: 'frankandoak',
    price: 89.5,
    occasions: ['Workwear', 'After-work'],
    closetMatches: 11,
    reason: 'Tuck it in for the office, leave it loose for drinks. Ivory works with every black piece here.',
    pairsWith: ['midi-skirt', 'dark-jeans', 'gold-hoops'],
    socialProof: {
      lines: ['Kept by 9 in 10 buyers', '860 reviews say it never needs ironing'],
      quote: { text: 'Desk at 9, rooftop at 7. Didn\u2019t change a thing.', name: 'Amara', role: 'investment banking analyst' },
    },
    image: 'blouse.png',
    placeholder: { kind: 'blouse', color: '#F3EBDD' },
    closetSlot: 'tops',
  },
  {
    id: 'pant',
    name: 'The Way-High Drape Pant, Black',
    shortName: 'Way-High Drape Pant',
    merchantId: 'everlane',
    price: 138.0,
    occasions: ['Workwear', 'Smart casual'],
    closetMatches: 10,
    reason: 'High waist and a fluid drape look sharp at your desk and relaxed at brunch.',
    pairsWith: ['striped-shirt', 'white-tee', 'cream-knit'],
    socialProof: {
      lines: ['Kept by 9 in 10 buyers', '1.8k reviews say it doesn’t wrinkle'],
      quote: { text: 'Survived a 12-hour close day and still looked pressed.', name: 'Maya', role: 'audit associate' },
    },
    image: 'pant.png',
    placeholder: { kind: 'pant', color: '#262426' },
    closetSlot: 'bottoms',
  },
  {
    id: 'blazer',
    name: 'Tailored Crepe Blazer, Black',
    shortName: 'Tailored Crepe Blazer',
    merchantId: 'frankandoak',
    price: 149.5,
    occasions: ['Workwear', 'After-work'],
    closetMatches: 12,
    reason: 'Neutral colour and structured fit make this office-safe and easy to dress down.',
    pairsWith: ['striped-shirt', 'white-tee', 'dark-jeans'],
    socialProof: {
      lines: ['Kept by 9 in 10 buyers', '1.2k reviews say it runs true to size'],
      quote: { text: 'Wore it to a client meeting, then straight to dinner.', name: 'Priya', role: 'analyst' },
    },
    image: 'blazer.png',
    placeholder: { kind: 'blazer', color: '#262426' },
    closetSlot: 'outerwear',
  },
  {
    id: 'belt',
    name: 'Leather Belt, Black',
    shortName: 'Leather Belt',
    merchantId: 'kotn',
    price: 55.0,
    occasions: ['Workwear', 'Casual'],
    closetMatches: 11,
    reason: 'A slim black belt finishes tucked-in looks and works with your jeans too.',
    pairsWith: ['dark-jeans', 'striped-shirt', 'midi-skirt'],
    socialProof: {
      lines: ['Kept by 94% of buyers', '640 reviews say it softens in a week'],
      quote: { text: 'First belt I own that works with jeans and trousers.', name: 'Hana', role: 'marketing coordinator' },
    },
    image: 'belt.png',
    placeholder: { kind: 'belt', color: '#262426', accent: '#C8C2B8' },
    closetSlot: 'accessories',
  },
  {
    id: 'flats',
    name: 'Selma Ballet Flat, Black Leather',
    shortName: 'Selma Ballet Flat',
    merchantId: 'stevemadden',
    price: 130.0,
    occasions: ['Workwear', 'Casual', 'After-work'],
    closetMatches: 12,
    reason: 'Polished enough for the office, comfy enough for your commute.',
    pairsWith: ['midi-skirt', 'dark-jeans', 'slip-dress'],
    socialProof: {
      lines: ['Kept by 8 in 10 buyers', '3.1k reviews say they’re comfy from day one'],
      quote: { text: 'Walked Bay Street to Union and back. No blisters.', name: 'Leah', role: 'financial analyst' },
    },
    image: 'flats.png',
    placeholder: { kind: 'flats', color: '#262426' },
    closetSlot: 'shoes',
  },
];

// ─── Stylist agent copy ─────────────────────────────────────────────────────

/** How many new outfits the new pieces unlock with Jane's closet. */
export const newOutfitsCount = 24;

export const stylistCopy = {
  name: 'Stylist',
  subtitle: 'Shops across Shopify merchants',
  greeting: 'Good morning, Jane. What are you looking for today?',

  workChipId: 'work',
  chips: [
    { id: 'capsule', label: 'Build me a capsule wardrobe' },
    { id: 'work', label: 'Build me an outfit for work' },
    { id: 'top', label: 'Find me a new top' },
    { id: 'belt', label: 'Find me a belt to go with pants in my closet' },
  ],

  /** Replies for chips that aren't part of the demo flow. Each ends by
   *  re-offering the work outfit chip. */
  comingSoonReplies: {
    capsule:
      'A full capsule is a bigger project, and I want to get it right. Let’s start with one great work outfit, then build out from there?',
    top:
      'Love that. Let\u2019s start with a full work outfit, and I\u2019ll include a top that goes from desk to drinks.',
    belt:
      'I’m still learning that one. For now, want me to build you an outfit for work? I’ll include a belt if it earns its spot.',
  } as Record<string, string>,

  steps: [
    'Searching across Shopify merchants…',
    'Checking against your closet…',
    'Styling your look…',
  ],

  outfitReply: `Here are ${products.length} new pieces that create ${newOutfitsCount} new outfits with what\u2019s already in your closet.`,
  bagTitle: 'Your bag',
  shippingNote: 'Shipping & taxes calculated at checkout',
};

// ─── Timings (milliseconds) ─────────────────────────────────────────────────
// Fixed so every demo run is identical.

export const timings = {
  greetingDelay: 350,
  /** Per-character speed for agent messages that "type in". */
  typeCharMs: 18,
  chipsAfterGreeting: 200,
  userToAgent: 450,
  /** Typing-dots duration before a short agent reply. */
  thinking: 700,
  /** Each "agent is working" step. */
  stepMs: 800,
  afterSteps: 300,
  afterReply: 250,
  /** Stagger between outfit cards entering. */
  cardStagger: 110,
  /** Confidence ring fill. */
  ringMs: 900,
  /** Hold to reset the demo. */
  resetHoldMs: 1000,
};

// ─── Checkout (sample data only, nothing is charged) ───────────────────────

export const checkoutCopy = {
  sheetTitle: 'Shop Pay',
  contactLabel: 'Contact & ship to',
  contactName: 'Jane D.',
  shipTo: 'Toronto, ON',
  paymentLabel: 'Payment',
  payment: 'Visa \u2022\u2022\u2022\u2022 4242',
  orderLabel: 'Order summary',
  taxRate: 0.13,
  taxLabel: 'Estimated tax (13% HST)',
  shipping: 0,
  shippingLabel: 'Free',
  /** {n} is replaced with the number of merchants. */
  protocolLine: 'Powered by Universal Commerce Protocol \u00b7 {n} merchants, one checkout.',
  payNow: 'Pay now',
  faceId: 'Face ID',
  processingTitle: 'Placing your orders',
  confirmed: 'Confirmed',
  successTitle: 'Your outfit is on its way',
  /** {n} is replaced with the number of orders (one per merchant). */
  successLine: '{n} orders placed \u00b7 tracking in Shop',
  seeInDressUp: 'See it in Dress Up',
  done: 'Done',
  ordered: 'Ordered',
  orderTitle: 'Your order',
  orderedNote: 'Arriving Thursday \u00b7 tracking in Shop',
};

export const checkoutTimings = {
  /** Face ID scan before it turns into a check. */
  faceIdScanMs: 900,
  faceIdCheckMs: 600,
  /** Pause before the first merchant confirms. */
  processingLeadMs: 350,
  /** Gap between each merchant confirming. */
  merchantStaggerMs: 450,
  afterConfirmedMs: 550,
};

// ─── Dress Up ───────────────────────────────────────────────────────────────
// Garments the avatar can wear. `source` sets the chip under the avatar:
// 'stylist' = "From Stylist", 'closet' = "In your closet".

export type TopId = 'striped' | 'tee' | 'knit' | 'blouse';
export type OuterId = 'blazer' | null;
export type BottomId = 'drape' | 'jeans' | 'yoga';

export interface Garment {
  name: string;
  /** One or two words for the label beside the avatar. */
  short: string;
  source: 'stylist' | 'closet';
  /** Product id (stylist) or closet item id, for the thumbnail. */
  refId: string;
}

export const dressUpGarments = {
  tops: {
    striped: { name: 'Striped button-up', short: 'Striped shirt', source: 'closet', refId: 'striped-shirt' },
    tee: { name: 'White tee', short: 'Tee', source: 'closet', refId: 'white-tee' },
    knit: { name: 'Cream knit sweater', short: 'Knit', source: 'closet', refId: 'cream-knit' },
    blouse: { name: 'Relaxed Satin Blouse', short: 'Blouse', source: 'stylist', refId: 'blouse' },
  } as Record<TopId, Garment>,
  outer: {
    blazer: { name: 'Tailored Crepe Blazer', short: 'Blazer', source: 'stylist', refId: 'blazer' },
  } as Record<'blazer', Garment>,
  bottoms: {
    drape: { name: 'Way-High Drape Pant', short: 'Drape pant', source: 'stylist', refId: 'pant' },
    jeans: { name: 'Dark-wash jeans', short: 'Jeans', source: 'closet', refId: 'dark-jeans' },
    yoga: { name: 'Black yoga pants', short: 'Yoga pants', source: 'closet', refId: 'yoga-pants' },
  } as Record<BottomId, Garment>,
  /** Always on, to keep the scope tight. */
  shoes: { name: 'Selma Ballet Flat', short: 'Flats', source: 'stylist', refId: 'flats' } as Garment,
  belt: { name: 'Leather Belt', short: 'Belt', source: 'stylist', refId: 'belt' } as Garment,
};

// Swipe order for tops (each may include the blazer) and bottoms.

export type TopOptionId =
  | 'blazer-blouse'
  | 'blazer-striped'
  | 'blouse'
  | 'striped'
  | 'blazer-tee'
  | 'tee'
  | 'knit';

export interface TopOption {
  id: TopOptionId;
  label: string;
  top: TopId;
  outer: OuterId;
}

export const topOptions: TopOption[] = [
  { id: 'blazer-blouse', label: 'Blazer + Satin blouse', top: 'blouse', outer: 'blazer' },
  { id: 'blazer-striped', label: 'Blazer + Striped button-up', top: 'striped', outer: 'blazer' },
  { id: 'blouse', label: 'Relaxed Satin Blouse', top: 'blouse', outer: null },
  { id: 'striped', label: 'Striped button-up', top: 'striped', outer: null },
  { id: 'blazer-tee', label: 'Blazer + White tee', top: 'tee', outer: 'blazer' },
  { id: 'tee', label: 'White tee', top: 'tee', outer: null },
  { id: 'knit', label: 'Cream knit sweater', top: 'knit', outer: null },
];

export const bottomOptions: BottomId[] = ['drape', 'jeans', 'yoga'];

export interface Look {
  top: TopOptionId;
  bottom: BottomId;
}

/** The complete Stylist outfit. */
export const stylistLook: Look = { top: 'blazer-blouse', bottom: 'drape' };

/** "View in Dress Up" from a product card: that piece worn with Jane's own
 *  closet pieces, so she can see how it fits what she already owns. */
export const productLooks: Record<string, Look> = {
  blouse: { top: 'blouse', bottom: 'jeans' },
  pant: { top: 'striped', bottom: 'drape' },
  blazer: { top: 'blazer-striped', bottom: 'jeans' },
  belt: { top: 'striped', bottom: 'jeans' },
  flats: { top: 'knit', bottom: 'jeans' },
};

/** What the avatar wears before the Stylist has suggested anything. */
export const closetLook: Look = { top: 'striped', bottom: 'jeans' };

// ── Style Match scores ──
// Keyed "topOption|bottom". Every combination has a fixed, hand-written
// result. Not every look scores high, which is what makes the high scores
// believable. 90% or more triggers the sparkle.

export interface StyleScore {
  occasion: Occasion;
  score: number;
  label: string;
  reason: string;
}

export const styleScores: Record<string, StyleScore> = {
  'blazer-blouse|drape': { occasion: 'Workwear', score: 95, label: 'Office-ready', reason: 'Sharp, soft and meeting-ready. This is the one.' },
  'blazer-blouse|jeans': { occasion: 'After-work', score: 92, label: 'Drinks-ready', reason: 'Satin and denim under a blazer: straight from your desk to the bar.' },
  'blazer-blouse|yoga': { occasion: 'Casual', score: 34, label: 'Office-ready', reason: 'The top half is client-ready, the yoga pants aren\u2019t. Try the drape pant.' },

  'blazer-striped|drape': { occasion: 'Workwear', score: 94, label: 'Office-ready', reason: 'Polished and meeting-ready.' },
  'blazer-striped|jeans': { occasion: 'Workwear', score: 86, label: 'Friday-ready', reason: 'Sharp up top, relaxed below. Perfect for casual Friday.' },
  'blazer-striped|yoga': { occasion: 'Casual', score: 31, label: 'Office-ready', reason: 'Love the blazer, but yoga pants read off-duty. Try the drape pant.' },

  'blouse|drape': { occasion: 'Workwear', score: 91, label: 'Office-ready', reason: 'Fluid and polished. Add the blazer for big meetings.' },
  'blouse|jeans': { occasion: 'After-work', score: 89, label: 'Date-ready', reason: 'Satin with denim is the easiest dressed-up look there is.' },
  'blouse|yoga': { occasion: 'Casual', score: 45, label: 'Errand-ready', reason: 'Pretty top, gym bottoms. Jeans would make this work.' },

  'striped|drape': { occasion: 'Workwear', score: 89, label: 'Office-ready', reason: 'Clean and crisp. Add the blazer to level up.' },
  'striped|jeans': { occasion: 'Weekend', score: 86, label: 'Brunch-ready', reason: 'Roll the sleeves and it\u2019s easy weekend polish.' },
  'striped|yoga': { occasion: 'Casual', score: 42, label: 'Errand-ready', reason: 'Comfy, but the crisp shirt fights the leggings. Try jeans.' },

  'blazer-tee|drape': { occasion: 'After-work', score: 90, label: 'Drinks-ready', reason: 'The tee keeps it relaxed, the drape pant keeps it sharp.' },
  'blazer-tee|jeans': { occasion: 'After-work', score: 88, label: 'Drinks-ready', reason: 'Swap the button-up for a tee and you\u2019re ready for drinks.' },
  'blazer-tee|yoga': { occasion: 'Casual', score: 38, label: 'Office-ready', reason: 'The blazer is working hard here. Jeans would carry it further.' },

  'tee|drape': { occasion: 'Casual', score: 72, label: 'Office-ready', reason: 'Fine for a quiet desk day. Add the blazer to level up.' },
  'tee|jeans': { occasion: 'Weekend', score: 80, label: 'Weekend-ready', reason: 'A classic. Add the knit if brunch runs long.' },
  'tee|yoga': { occasion: 'Casual', score: 64, label: 'Errand-ready', reason: 'Perfect for errands, not quite out-the-door.' },

  'knit|drape': { occasion: 'Workwear', score: 83, label: 'Office-ready', reason: 'Soft and polished, great for cold office days.' },
  'knit|jeans': { occasion: 'Weekend', score: 91, label: 'Brunch-ready', reason: 'Cozy, put-together and ready for brunch.' },
  'knit|yoga': { occasion: 'Casual', score: 58, label: 'Lounge-ready', reason: 'Comfy for a slow Sunday. Jeans would take it out the door.' },
};

/** Score at or above this triggers the sparkle burst. */
export const sparkleThreshold = 90;

/** Progress meter: "3 of 10 work looks created". Starts at 2 so the first
 *  save already feels like progress. */
export const looksProgress = { start: 2, goal: 10, label: 'work looks created' };

export const dressUpCopy = {
  title: 'Dress Up',
  swipeHint: 'Swipe her top or bottom half to try pieces',
  legendStylist: 'From Stylist',
  legendCloset: 'Your closet',
  styleMatch: 'Style Match',
  wearingLabel: 'Wearing',
  tryingOn: 'Trying on',
  fromStylist: 'From Stylist',
  inCloset: 'In your closet',
  mixed: 'Stylist + your closet',
  stylistLookButton: 'Stylist look',
  saveLook: 'Save this look',
  savedLook: 'Saved',
  savedToast: 'New look unlocked \u2728',
  myLooks: 'My Looks',
  myLooksEmpty: 'Save looks you love and they\u2019ll live here.',
  backToBag: 'Back to bag',
};

// ─── Closet ─────────────────────────────────────────────────────────────────

export const closetSections: { id: ClosetCategory; label: string; kind: 'rail' | 'shelf' | 'rack' | 'tray' }[] = [
  { id: 'tops', label: 'Tops', kind: 'rail' },
  { id: 'outerwear', label: 'Outerwear', kind: 'rail' },
  { id: 'bottoms', label: 'Bottoms', kind: 'shelf' },
  { id: 'shoes', label: 'Shoes', kind: 'rack' },
  { id: 'accessories', label: 'Accessories', kind: 'tray' },
];

/** "Style this in Dress Up" from the Closet. Items not listed here (the
 *  avatar can't wear them yet) don't show the button. */
export const closetDressUpLooks: Record<string, Look> = {
  'striped-shirt': { top: 'striped', bottom: 'jeans' },
  'white-tee': { top: 'tee', bottom: 'jeans' },
  'cream-knit': { top: 'knit', bottom: 'jeans' },
  'dark-jeans': { top: 'striped', bottom: 'jeans' },
  'yoga-pants': { top: 'tee', bottom: 'yoga' },
};

export const closetCopy = {
  title: 'Closet',
  /** {n} is replaced with the piece count. */
  count: '{n} pieces',
  inBagCount: '{n} in your bag',
  all: 'All',
  showPicks: 'Show Stylist picks',
  showPicksNote: 'See your bag in your closet before you buy',
  inYourBag: 'In your bag',
  newTag: 'New',
  wornIn: 'Worn in {n} looks',
  goesWith: 'Goes with {n} of {total} pieces',
  pairsWith: 'Pairs with',
  styleInDressUp: 'Style this in Dress Up',
  viewInBag: 'View in bag',
  inClosetLine: 'In your closet',
  previewLine: 'In your bag · {merchant}',
  newLine: 'New · {merchant}',
  addSoon: 'Adding pieces is coming next',
};
