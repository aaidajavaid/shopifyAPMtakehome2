import { motion } from 'framer-motion';
import { useAppState, useDispatch, type Tab } from '../state/store';

const tabs: { id: Tab; label: string }[] = [
  { id: 'stylist', label: 'Stylist' },
  { id: 'dressup', label: 'Dress Up' },
  { id: 'closet', label: 'Closet' },
];

function TabIcon({ id, active }: { id: Tab; active: boolean }) {
  const stroke = 'currentColor';
  if (id === 'stylist') {
    return (
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden>
        <path
          d="M14 4.5c-5.5 0-10 3.7-10 8.4 0 2.6 1.4 4.9 3.6 6.4l-.9 3.6c-.1.5.4.9.8.6l4-2.3c.8.2 1.6.2 2.5.2 5.5 0 10-3.7 10-8.4S19.5 4.5 14 4.5Z"
          fill={active ? 'currentColor' : 'none'}
          stroke={stroke}
          strokeWidth="1.7"
          strokeLinejoin="round"
        />
        <path
          d="M14 8.6l1.1 2.7 2.7 1.1-2.7 1.1L14 16.2l-1.1-2.7-2.7-1.1 2.7-1.1z"
          fill={active ? 'var(--warm-white)' : 'currentColor'}
        />
      </svg>
    );
  }
  if (id === 'dressup') {
    return (
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden>
        <path
          d="M11 3.8c.4 1.6 1.6 2.6 3 2.6s2.6-1 3-2.6l2.2.9-.9 6.1 4.3 12.4c.1.4-.2.8-.6.8H6c-.4 0-.7-.4-.6-.8l4.3-12.4-.9-6.1Z"
          fill={active ? 'currentColor' : 'none'}
          stroke={stroke}
          strokeWidth="1.7"
          strokeLinejoin="round"
        />
        <path d="M9.9 11h8.2" stroke={active ? 'var(--warm-white)' : stroke} strokeWidth="1.5" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden>
      <rect
        x="5"
        y="3.8"
        width="18"
        height="19.4"
        rx="2.6"
        fill={active ? 'currentColor' : 'none'}
        stroke={stroke}
        strokeWidth="1.7"
      />
      <path d="M14 4v19" stroke={active ? 'var(--warm-white)' : stroke} strokeWidth="1.5" />
      <circle cx="11.6" cy="13" r="1" fill={active ? 'var(--warm-white)' : stroke} />
      <circle cx="16.4" cy="13" r="1" fill={active ? 'var(--warm-white)' : stroke} />
      <path d="M8 23.2v1.4M20 23.2v1.4" stroke={stroke} strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

export function TabBar() {
  const { tab } = useAppState();
  const dispatch = useDispatch();

  return (
    <nav className="tabbar" aria-label="Main">
      {tabs.map((t) => {
        const active = t.id === tab;
        return (
          <button
            key={t.id}
            className={'tabbar__item' + (active ? ' is-active' : '')}
            aria-current={active ? 'page' : undefined}
            onClick={() => dispatch({ type: 'setTab', tab: t.id })}
          >
            <motion.span
              className="tabbar__icon"
              whileTap={{ scale: 0.86 }}
              transition={{ type: 'spring', stiffness: 600, damping: 30 }}
            >
              <TabIcon id={t.id} active={active} />
            </motion.span>
            <span className="tabbar__label">{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
