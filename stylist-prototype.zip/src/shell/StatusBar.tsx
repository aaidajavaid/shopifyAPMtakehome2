import { timings } from '../data/demo';
import { useReset } from '../state/store';
import { useLongPress } from './useLongPress';

/** Fake iOS status bar shown inside the desktop iPhone frame.
 *  Hidden demo reset: hold the clock for 1 second. */
export function StatusBar() {
  const reset = useReset();
  const press = useLongPress(reset, timings.resetHoldMs);

  return (
    <div className="statusbar">
      <div className="statusbar__time" {...press}>
        9:41
      </div>
      <div className="statusbar__icons" aria-hidden>
        {/* Signal */}
        <svg width="18" height="12" viewBox="0 0 18 12">
          <rect x="0" y="8" width="3" height="4" rx="1" fill="currentColor" />
          <rect x="5" y="5.5" width="3" height="6.5" rx="1" fill="currentColor" />
          <rect x="10" y="3" width="3" height="9" rx="1" fill="currentColor" />
          <rect x="15" y="0" width="3" height="12" rx="1" fill="currentColor" />
        </svg>
        {/* Wi-Fi */}
        <svg width="17" height="12" viewBox="0 0 17 12">
          <path
            d="M8.5 2.4c2.3 0 4.4.9 6 2.4l1.2-1.2A10.2 10.2 0 0 0 8.5.7 10.2 10.2 0 0 0 1.3 3.6l1.2 1.2c1.6-1.5 3.7-2.4 6-2.4Z"
            fill="currentColor"
          />
          <path d="M8.5 5.8c1.4 0 2.6.5 3.6 1.4l1.2-1.2a6.8 6.8 0 0 0-9.6 0l1.2 1.2c1-.9 2.2-1.4 3.6-1.4Z" fill="currentColor" />
          <path d="M8.5 9.1c.5 0 1 .2 1.3.5L8.5 11 7.2 9.6c.3-.3.8-.5 1.3-.5Z" fill="currentColor" />
        </svg>
        {/* Battery */}
        <svg width="27" height="13" viewBox="0 0 27 13">
          <rect x="0.5" y="0.5" width="23" height="12" rx="3.8" fill="none" stroke="currentColor" opacity="0.4" />
          <rect x="2" y="2" width="20" height="9" rx="2.4" fill="currentColor" />
          <path d="M25 4.5v4c.8-.3 1.3-1.1 1.3-2s-.5-1.7-1.3-2Z" fill="currentColor" opacity="0.45" />
        </svg>
      </div>
    </div>
  );
}
