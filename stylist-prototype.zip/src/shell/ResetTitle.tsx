import type { ReactNode } from 'react';
import { timings } from '../data/demo';
import { useReset } from '../state/store';
import { useLongPress } from './useLongPress';

/** Wraps a screen title. Holding it for 1 second resets the demo. This is the
 *  reset gesture on a real phone, where iOS draws its own status bar. */
export function ResetTitle({ children, className }: { children: ReactNode; className?: string }) {
  const reset = useReset();
  const press = useLongPress(reset, timings.resetHoldMs);
  return (
    <div className={className} style={{ WebkitUserSelect: 'none', userSelect: 'none', WebkitTouchCallout: 'none' }} {...press}>
      {children}
    </div>
  );
}
