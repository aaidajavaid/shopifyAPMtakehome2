import { AnimatePresence, motion } from 'framer-motion';
import { useEffect } from 'react';
import { useAppState, useDispatch } from '../state/store';

export function Toast() {
  const { toast } = useAppState();
  const dispatch = useDispatch();

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => dispatch({ type: 'clearToast', id: toast.id }), 2200);
    return () => window.clearTimeout(t);
  }, [toast, dispatch]);

  return (
    <div className="toast-layer" aria-live="polite">
      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast.id}
            className="toast"
            initial={{ opacity: 0, y: -16, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 500, damping: 34 }}
          >
            {toast.text}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
