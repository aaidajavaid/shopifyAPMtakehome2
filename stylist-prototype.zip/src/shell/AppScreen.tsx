import { motion } from 'framer-motion';
import type { ReactNode } from 'react';
import { useAppState, type Tab } from '../state/store';
import { StylistScreen } from '../screens/stylist/StylistScreen';
import { ClosetScreen } from '../screens/closet/ClosetScreen';
import { ClosetItemSheet } from '../screens/closet/ClosetItemSheet';
import { DressUpScreen } from '../screens/dressup/DressUpScreen';
import { ShopPaySheet } from '../screens/checkout/ShopPaySheet';
import { TabBar } from './TabBar';
import { Toast } from './Toast';

/** Every tab stays mounted with its own scroll container, so switching tabs
 *  keeps each one's scroll position. Tabs crossfade quickly. */
function TabPanel({ id, children }: { id: Tab; children: ReactNode }) {
  const { tab } = useAppState();
  const active = tab === id;
  return (
    <motion.section
      className="tabpanel"
      aria-hidden={!active}
      initial={false}
      animate={active ? { opacity: 1, visibility: 'visible' } : { opacity: 0, transitionEnd: { visibility: 'hidden' } }}
      transition={{ duration: 0.18, ease: [0.25, 0.1, 0.25, 1] }}
      style={{ pointerEvents: active ? 'auto' : 'none', zIndex: active ? 1 : 0 }}
    >
      {children}
    </motion.section>
  );
}

export function AppScreen() {
  return (
    <div className="app">
      <TabPanel id="stylist">
        <StylistScreen />
      </TabPanel>
      <TabPanel id="dressup">
        <DressUpScreen />
      </TabPanel>
      <TabPanel id="closet">
        <ClosetScreen />
      </TabPanel>
      <TabBar />
      <ClosetItemSheet />
      <ShopPaySheet />
      <Toast />
    </div>
  );
}
