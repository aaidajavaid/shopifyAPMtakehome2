import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { StatusBar } from './StatusBar';
import './shell.css';

/** 'frame' = desktop, app shown inside an iPhone 15 frame.
 *  'phone' = real phone (viewport under 500px), app runs full-screen. */
export type DisplayMode = 'frame' | 'phone';

const ModeCtx = createContext<DisplayMode>('frame');
export const useDisplayMode = () => useContext(ModeCtx);

const SCREEN_W = 390;
const SCREEN_H = 844;
const BEZEL = 12;

function getMode(): DisplayMode {
  return window.innerWidth < 500 ? 'phone' : 'frame';
}

function getScale() {
  const pad = 48;
  const s = Math.min((window.innerHeight - pad) / (SCREEN_H + BEZEL * 2), (window.innerWidth - pad) / (SCREEN_W + BEZEL * 2));
  return Math.min(1, s);
}

export function DeviceFrame({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<DisplayMode>(getMode);
  const [scale, setScale] = useState(getScale);

  useEffect(() => {
    const onResize = () => {
      setMode(getMode());
      setScale(getScale());
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  if (mode === 'phone') {
    return (
      <ModeCtx.Provider value="phone">
        <div className="phone-root">
          <div className="screen screen--phone">{children}</div>
        </div>
      </ModeCtx.Provider>
    );
  }

  return (
    <ModeCtx.Provider value="frame">
      <div className="desk">
        {/* The sized wrapper takes the scaled footprint so centring is exact. */}
        <div style={{ width: (SCREEN_W + BEZEL * 2) * scale, height: (SCREEN_H + BEZEL * 2) * scale }}>
        <div
          className="device"
          style={{
            width: SCREEN_W + BEZEL * 2,
            height: SCREEN_H + BEZEL * 2,
            transform: `scale(${scale})`,
          }}
        >
          <div className="device__buttons" aria-hidden />
          <div className="screen screen--frame" style={{ width: SCREEN_W, height: SCREEN_H }}>
            {children}
            <StatusBar />
            <div className="dynamic-island" aria-hidden />
            <div className="home-indicator" aria-hidden />
          </div>
        </div>
        </div>
      </div>
    </ModeCtx.Provider>
  );
}
