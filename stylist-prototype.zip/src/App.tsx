import { MotionConfig } from 'framer-motion';
import { useCallback, useState } from 'react';
import { ResetCtx, StoreProvider } from './state/store';
import { DeviceFrame } from './shell/DeviceFrame';
import { AppScreen } from './shell/AppScreen';

export function App() {
  // Re-keying remounts the whole app: fresh state, all timers cancelled.
  const [resetKey, setResetKey] = useState(0);
  const reset = useCallback(() => setResetKey((k) => k + 1), []);

  return (
    <MotionConfig reducedMotion="user">
      <ResetCtx.Provider value={reset}>
        <StoreProvider key={resetKey}>
          <DeviceFrame>
            <AppScreen />
          </DeviceFrame>
        </StoreProvider>
      </ResetCtx.Provider>
    </MotionConfig>
  );
}
