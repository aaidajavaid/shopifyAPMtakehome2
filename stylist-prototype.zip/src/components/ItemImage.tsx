import { useEffect, useState } from 'react';
import type { Placeholder } from '../data/demo';
import { PlaceholderArt } from './PlaceholderArt';

/* Remembers which image files exist so placeholders never flicker on
 * re-render. Images are local files in /public only. */
const known = new Map<string, boolean>();

function useImageExists(src: string) {
  const [exists, setExists] = useState<boolean | undefined>(known.get(src));
  useEffect(() => {
    if (known.has(src)) {
      setExists(known.get(src));
      return;
    }
    let live = true;
    const img = new Image();
    img.onload = () => {
      known.set(src, true);
      if (live) setExists(true);
    };
    img.onerror = () => {
      known.set(src, false);
      if (live) setExists(false);
    };
    img.src = src;
    return () => {
      live = false;
    };
  }, [src]);
  return exists;
}

interface Props {
  folder: 'products' | 'closet';
  file: string;
  placeholder: Placeholder;
  alt: string;
  className?: string;
  /** Padding for the placeholder drawing, as a % of the box. */
  inset?: number;
}

export function ItemImage({ folder, file, placeholder, alt, className, inset = 10 }: Props) {
  const src = `/images/${folder}/${file}`;
  const exists = useImageExists(src);

  return (
    <div className={'itemimg ' + (className ?? '')} role="img" aria-label={alt}>
      {exists ? (
        <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
      ) : (
        <div style={{ position: 'absolute', inset: `${inset}%` }}>
          <PlaceholderArt placeholder={placeholder} />
        </div>
      )}
    </div>
  );
}
