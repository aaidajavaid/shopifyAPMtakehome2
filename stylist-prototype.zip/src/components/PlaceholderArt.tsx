import { useId } from 'react';
import type { Placeholder } from '../data/demo';

/** Mix a hex colour toward black (amt < 0) or white (amt > 0). */
export function shade(hex: string, amt: number) {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  const t = amt < 0 ? 0 : 255;
  const p = Math.abs(amt);
  const mix = (c: number) => Math.round(c + (t - c) * p);
  return `rgb(${mix(r)}, ${mix(g)}, ${mix(b)})`;
}

function isDark(hex: string) {
  const n = parseInt(hex.slice(1), 16);
  const lum = 0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255);
  return lum < 90;
}

/** Flat illustrated stand-in for an item photo, drawn in the item's colour. */
export function PlaceholderArt({ placeholder }: { placeholder: Placeholder }) {
  const uid = useId().replace(/:/g, '');
  const { kind, color } = placeholder;
  const dark = isDark(color);
  // Dark garments get lighter detail lines so they read on the backdrop.
  const edge = dark ? shade(color, 0.12) : shade(color, -0.18);
  const detail = dark ? shade(color, 0.2) : shade(color, -0.12);
  const deep = dark ? shade(color, -0.35) : shade(color, -0.08);
  const accent = placeholder.accent ?? detail;
  const s = { fill: color, stroke: edge, strokeWidth: 1.2, strokeLinejoin: 'round' as const };
  const line = { fill: 'none', stroke: detail, strokeWidth: 1.2, strokeLinecap: 'round' as const };

  let art: JSX.Element;
  switch (kind) {
    case 'shirt': {
      const body =
        'M52 20 L60 28 L68 20 L80 25 Q86 28 88 36 L98 84 L88 87 L84 52 L84 100 Q84 103 81 103 L39 103 Q36 103 36 100 L36 52 L32 87 L22 84 L32 36 Q34 28 40 25 Z';
      art = (
        <>
          <defs>
            <clipPath id={`c${uid}`}>
              <path d={body} />
            </clipPath>
          </defs>
          <path d={body} {...s} />
          {placeholder.accent && (
            <g clipPath={`url(#c${uid})`} stroke={placeholder.accent} strokeWidth="1.6" opacity="0.75">
              {Array.from({ length: 14 }, (_, i) => (
                <line key={i} x1={22 + i * 6} y1="14" x2={22 + i * 6} y2="108" />
              ))}
            </g>
          )}
          <path d="M52 20 L60 28 L55 35 L47 23 Z" fill={shade(color, dark ? 0.1 : -0.04)} stroke={edge} strokeWidth="1" />
          <path d="M68 20 L60 28 L65 35 L73 23 Z" fill={shade(color, dark ? 0.1 : -0.04)} stroke={edge} strokeWidth="1" />
          <line x1="60" y1="30" x2="60" y2="103" stroke={edge} strokeWidth="1" />
          {[42, 56, 70, 84, 97].map((y) => (
            <circle key={y} cx="62.5" cy={y} r="1.3" fill={edge} />
          ))}
          <path d="M23 80 L32.5 82.5 M97 80 L87.5 82.5" {...line} stroke={edge} />
        </>
      );
      break;
    }
    case 'blouse':
      art = (
        <>
          <path
            d="M48 20 Q60 24 72 20 L82 25 Q89 29 91 38 L99 84 Q99 88 95 89 L88 90 L85 56 L86 98 Q73 104 60 101 Q47 104 34 98 L35 56 L32 90 L25 89 Q21 88 21 84 L29 38 Q31 29 38 25 Z"
            {...s}
          />
          <path d="M48 20 L60 42 L72 20" fill="none" stroke={edge} strokeWidth="1.4" strokeLinejoin="round" />
          <path d="M60 42 L60 100" {...line} opacity="0.6" />
          <path d="M45 50 Q47 74 42 98 M75 50 Q73 74 78 98" {...line} opacity="0.45" />
          <path d="M24 84 L33 86 M96 84 L87 86" {...line} strokeWidth="1.6" />
          <path d="M40 28 Q36 44 37 56 M80 28 Q84 44 83 56" {...line} opacity="0.35" />
        </>
      );
      break;
    case 'tee':
      art = (
        <>
          <path
            d="M49 22 Q60 31 71 22 L85 26 L101 42 L91 54 L84 49 L84 100 Q84 103 81 103 L39 103 Q36 103 36 100 L36 49 L29 54 L19 42 L35 26 Z"
            {...s}
          />
          <path d="M49 22 Q60 31 71 22" {...line} stroke={edge} strokeWidth="2" />
          <path d="M31 51 L22 42 M89 51 L98 42" {...line} />
        </>
      );
      break;
    case 'sweater':
    case 'cardigan': {
      const body =
        'M47 22 Q60 30 73 22 L82 25 Q88 28 90 36 L99 88 L87 91 L84 54 L84 100 Q84 103 81 103 L39 103 Q36 103 36 100 L36 54 L33 91 L21 88 L30 36 Q32 28 38 25 Z';
      art = (
        <>
          <path d={body} {...s} />
          <path d="M37 96 L83 96 M22 83 L33 85.5 M98 83 L87 85.5" {...line} strokeWidth="1.6" />
          <path d="M47 22 Q60 30 73 22" {...line} strokeWidth="2.4" stroke={edge} />
          {kind === 'cardigan' ? (
            <>
              <path d="M48 23 L60 60 L72 23 Q60 30 48 23 Z" fill={shade(color, -0.16)} stroke={edge} strokeWidth="1" />
              <line x1="60" y1="60" x2="60" y2="103" stroke={edge} strokeWidth="1.2" />
              {[68, 78, 88].map((y) => (
                <circle key={y} cx="63" cy={y} r="1.6" fill={edge} />
              ))}
            </>
          ) : (
            [46, 54, 62, 70, 78].map((x) => <path key={x} d={`M${x} 36 L${x} 92`} {...line} opacity="0.35" />)
          )}
        </>
      );
      break;
    }
    case 'blazer':
      art = (
        <>
          <path
            d="M50 20 L60 24 L70 20 L81 25 Q87 28 89 36 L98 86 L88 89 L84 54 L85 92 Q85 95 82 95 L38 95 Q35 95 35 92 L36 54 L32 89 L22 86 L31 36 Q33 28 39 25 Z"
            {...s}
          />
          <path d="M50 20 L60 24 L70 20 L60 58 Z" fill="#F4EFE8" stroke={edge} strokeWidth="1" />
          <path d="M50 20 L60 58 L56 64 L44 34 L49 30 L44 26 Z" fill={shade(color, dark ? 0.08 : -0.06)} stroke={edge} strokeWidth="1" />
          <path d="M70 20 L60 58 L64 64 L76 34 L71 30 L76 26 Z" fill={shade(color, dark ? 0.08 : -0.06)} stroke={edge} strokeWidth="1" />
          <circle cx="62" cy="70" r="1.8" fill={detail} />
          <circle cx="62" cy="81" r="1.8" fill={detail} />
          <path d="M41 78 L52 78 M68 78 L79 78" {...line} />
          <path d="M23 82 L32.5 84.5 M97 82 L87.5 84.5" {...line} />
        </>
      );
      break;
    case 'coat':
      art = (
        <>
          <path
            d="M49 16 L60 20 L71 16 L82 21 Q88 24 90 32 L100 92 L89 95 L85 52 L88 108 Q88 111 85 111 L35 111 Q32 111 32 108 L35 52 L31 95 L20 92 L30 32 Q32 24 38 21 Z"
            {...s}
          />
          <path d="M49 16 L60 20 L71 16 L60 46 Z" fill="#F4EFE8" stroke={edge} strokeWidth="1" />
          <path d="M49 16 L60 46 L54 54 L42 30 L47 26 L42 22 Z" fill={shade(color, -0.06)} stroke={edge} strokeWidth="1" />
          <path d="M71 16 L60 46 L66 54 L78 30 L73 26 L78 22 Z" fill={shade(color, -0.06)} stroke={edge} strokeWidth="1" />
          <rect x="34.5" y="63" width="51" height="6" rx="1.5" fill={accent} stroke={edge} strokeWidth="0.8" />
          <rect x="56" y="61.5" width="8" height="9" rx="1.5" fill="none" stroke={shade(color, -0.4)} strokeWidth="1.4" />
          {[54, 76, 88].map((y) => (
            <g key={y}>
              <circle cx="52" cy={y} r="1.6" fill={shade(color, -0.4)} />
              <circle cx="68" cy={y} r="1.6" fill={shade(color, -0.4)} />
            </g>
          ))}
          <line x1="60" y1="70" x2="60" y2="111" stroke={edge} strokeWidth="1" />
        </>
      );
      break;
    case 'dress':
      art = (
        <>
          <path d="M48 16 L47 33 M72 16 L73 33" stroke={edge} strokeWidth="1.6" strokeLinecap="round" />
          <path d="M45 33 Q60 40 75 33 L76 56 L89 106 Q60 112 31 106 L44 56 Z" {...s} />
          <path d="M44 56 Q60 60 76 56" {...line} />
          <path d="M52 62 L46 104 M68 62 L74 104 M60 62 L60 108" {...line} opacity="0.5" />
        </>
      );
      break;
    case 'pant':
      art = (
        <>
          <path d="M37 14 L83 14 L85 26 L92 106 L67 106 L60 46 L53 106 L28 106 L35 26 Z" {...s} />
          <path d="M36 23 L84 23" {...line} />
          <path d="M60 23 L60 40" {...line} />
          <path d="M45 30 L41 104 M75 30 L79 104" {...line} opacity="0.55" />
          <path d="M40 23 L40 15 M80 23 L80 15" {...line} opacity="0.5" />
        </>
      );
      break;
    case 'jeans':
      art = (
        <>
          <path d="M39 14 L81 14 L83 26 L85 106 L64 106 L60 48 L56 106 L35 106 L37 26 Z" {...s} />
          <path d="M38 22 L82 22" fill="none" stroke={accent} strokeWidth="1" strokeDasharray="2 2" />
          <path d="M60 22 L60 44 Q57 44 55 40" fill="none" stroke={accent} strokeWidth="1" strokeDasharray="2 2" />
          <path d="M39 30 Q47 32 50 26 M81 30 Q73 32 70 26" fill="none" stroke={accent} strokeWidth="1" strokeDasharray="2 2" />
          <path d="M36 100 L56 100 M64 100 L84 100" fill="none" stroke={accent} strokeWidth="1" strokeDasharray="2 2" />
          <circle cx="60" cy="18" r="1.6" fill={accent} />
        </>
      );
      break;
    case 'leggings':
      art = (
        <>
          <path d="M41 14 L79 14 L81 30 L77 106 L64 106 L60 52 L56 106 L43 106 L39 30 Z" {...s} />
          <path d="M40.5 25 L79.5 25" {...line} strokeWidth="1.6" />
          <path d="M48 40 L49 100 M72 40 L71 100" {...line} opacity="0.35" />
        </>
      );
      break;
    case 'skirt':
      art = (
        <>
          <path d="M41 18 L79 18 L81 28 L94 102 Q60 108 26 102 L39 28 Z" {...s} />
          <path d="M40 27 L80 27" {...line} />
          <path d="M50 30 L42 104 M60 30 L60 106 M70 30 L78 104" {...line} opacity="0.45" />
        </>
      );
      break;
    case 'flats': {
      const shoe =
        'M16 80 Q17 71 30 67 L50 63 Q60 68 72 67 Q88 64 100 71 Q106 76 103 81 Q101 85 94 85 L23 85 Q16 85 16 80 Z';
      art = (
        <>
          <g transform="translate(8 -16)" opacity="0.92">
            <path d={shoe} fill={shade(color, dark ? 0.06 : -0.06)} stroke={edge} strokeWidth="1.2" />
            <path d="M48 64 Q68 74 97 71 Q82 64 70 65 Q58 66 48 64 Z" fill={deep} />
          </g>
          <path d={shoe} {...s} />
          <path d="M48 64 Q68 74 97 71 Q82 64 70 65 Q58 66 48 64 Z" fill={deep} />
          <path d="M23 85 L94 85" stroke={edge} strokeWidth="2" strokeLinecap="round" />
          <path d="M30 85 L30 80 L36 80 L36 85" fill={shade(color, -0.3)} />
        </>
      );
      break;
    }
    case 'sneaker':
      art = (
        <>
          <path d="M15 79 Q17 62 34 58 L50 49 Q59 46 64 53 L72 60 Q92 61 102 71 Q107 77 105 82 L15 84 Z" {...s} />
          <path d="M14 82 L106 80 Q107 89 100 90 L20 91 Q13 91 14 82 Z" fill={accent} stroke={edge} strokeWidth="1" />
          <path d="M52 55 L60 62 M47 59 L55 66 M42 63 L50 70" {...line} strokeWidth="1.6" />
          <path d="M30 70 Q46 76 72 66" {...line} opacity="0.6" />
        </>
      );
      break;
    case 'boot':
      art = (
        <>
          <path d="M32 24 L58 24 L59 60 Q79 62 96 71 Q103 76 101 84 L31 86 Q27 56 32 24 Z" {...s} />
          <rect x="30" y="85" width="13" height="11" rx="1.5" fill={shade(color, -0.2)} stroke={edge} strokeWidth="1" />
          <path d="M43 86 L101 84" stroke={edge} strokeWidth="2" strokeLinecap="round" />
          <path d="M45 30 L46 58" {...line} />
          <rect x="40" y="22" width="12" height="8" rx="2" fill={shade(color, dark ? 0.14 : -0.12)} />
        </>
      );
      break;
    case 'belt':
      art = (
        <>
          <path d="M10 52 L96 52 Q104 52 106 60 Q104 68 96 68 L10 68 Z" {...s} />
          <path d="M14 55.5 L94 55.5 M14 64.5 L94 64.5" {...line} strokeDasharray="2 2.2" opacity="0.7" />
          {[80, 87, 94].map((x) => (
            <circle key={x} cx={x} cy="60" r="1.5" fill={shade(color, -0.4)} stroke={detail} strokeWidth="0.6" />
          ))}
          <rect x="42" y="46" width="20" height="28" rx="3" fill="none" stroke={accent} strokeWidth="3.4" />
          <line x1="44" y1="60" x2="68" y2="60" stroke={accent} strokeWidth="2.2" strokeLinecap="round" />
          <rect x="64" y="51" width="6" height="18" rx="1" fill={color} stroke={edge} strokeWidth="1" />
        </>
      );
      break;
    case 'tote':
      art = (
        <>
          <path d="M42 50 Q42 20 60 20 Q78 20 78 50" fill="none" stroke={shade(color, -0.25)} strokeWidth="5" strokeLinecap="round" />
          <path d="M28 48 L92 48 L99 104 Q99 106 97 106 L23 106 Q21 106 21 104 Z" {...s} />
          <path d="M27.5 56 L92.5 56" {...line} />
          <path d="M24 98 L96 98" {...line} strokeDasharray="2 2" />
          <circle cx="60" cy="62" r="2.4" fill={shade(color, -0.3)} />
        </>
      );
      break;
    case 'hoops':
      art = (
        <>
          <circle cx="44" cy="62" r="21" fill="none" stroke={shade(color, -0.2)} strokeWidth="6.5" />
          <circle cx="44" cy="62" r="21" fill="none" stroke={color} strokeWidth="5" />
          <path d="M30 50 A18 18 0 0 1 44 43" fill="none" stroke="#FFF6D8" strokeWidth="1.6" strokeLinecap="round" />
          <circle cx="78" cy="66" r="21" fill="none" stroke={shade(color, -0.2)} strokeWidth="6.5" />
          <circle cx="78" cy="66" r="21" fill="none" stroke={color} strokeWidth="5" />
          <path d="M64 54 A18 18 0 0 1 78 47" fill="none" stroke="#FFF6D8" strokeWidth="1.6" strokeLinecap="round" />
        </>
      );
      break;
  }

  return (
    <svg viewBox="0 0 120 120" width="100%" height="100%" aria-hidden preserveAspectRatio="xMidYMid meet">
      <ellipse cx="60" cy="112" rx="34" ry="3.5" fill="rgba(60,45,30,0.07)" />
      {art}
    </svg>
  );
}
