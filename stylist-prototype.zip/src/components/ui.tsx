import { animate, motion, useInView, useMotionValue, useReducedMotion, useTransform } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import { occasionColors, scoreBands, timings, type Occasion } from '../data/demo';
import './ui.css';

export const spring = { type: 'spring', stiffness: 420, damping: 34 } as const;
export const softSpring = { type: 'spring', stiffness: 260, damping: 30 } as const;

export const formatPrice = (n: number) =>
  '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function matchPercent(matches: number, total: number) {
  return Math.round((matches / total) * 100);
}

export const scoreBand = (value: number) => scoreBands.find((b) => value >= b.min) ?? scoreBands[scoreBands.length - 1];

export function OccasionTag({ occasion }: { occasion: Occasion }) {
  const c = occasionColors[occasion];
  return (
    <span className="otag" style={{ background: c.bg, color: c.fg }}>
      {occasion}
    </span>
  );
}

export function OccasionTags({ occasions }: { occasions: Occasion[] }) {
  return (
    <div className="otags">
      {occasions.map((o) => (
        <OccasionTag key={o} occasion={o} />
      ))}
    </div>
  );
}

/** Circular score ring. Fills from 0 to `value` the first time it scrolls into view. */
export function ScoreRing({ value, size = 52, stroke = 5 }: { value: number; size?: number; stroke?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.8 });
  const reduce = useReducedMotion();
  const progress = useMotionValue(0);
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const dash = useTransform(progress, (p) => `${(p / 100) * circ} ${circ}`);
  const [shown, setShown] = useState(0);
  const band = scoreBand(value);

  useEffect(() => {
    if (!inView) return;
    if (reduce) {
      progress.set(value);
      setShown(value);
      return;
    }
    const controls = animate(progress, value, {
      duration: timings.ringMs / 1000,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setShown(Math.round(v)),
    });
    return () => controls.stop();
  }, [inView, value, reduce, progress]);

  return (
    <div ref={ref} className="ring" style={{ width: size, height: size }} aria-label={`${value} percent`} role="img">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={band.soft} strokeWidth={stroke} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={band.color}
          strokeWidth={stroke}
          strokeLinecap="round"
          style={{ strokeDasharray: dash }}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <span className="ring__value" aria-hidden>
        <span>
          {shown}
          <span className="ring__pct">%</span>
        </span>
      </span>
    </div>
  );
}

/** Text that types in at a fixed speed. The full text is laid out from the
 *  first frame (the untyped part is invisible), so the bubble never jumps. */
export function TypedText({ text }: { text: string }) {
  const reduce = useReducedMotion();
  const [count, setCount] = useState(reduce ? text.length : 0);

  useEffect(() => {
    if (reduce) {
      setCount(text.length);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const n = Math.min(text.length, Math.floor((now - start) / timings.typeCharMs) + 1);
      setCount(n);
      if (n < text.length) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [text, reduce]);

  return (
    <>
      <span className="sr-only">{text}</span>
      <span aria-hidden>
        {text.slice(0, count)}
        <span style={{ color: 'transparent' }}>{text.slice(count)}</span>
      </span>
    </>
  );
}

/** Milliseconds a TypedText takes, so the flow can wait for it exactly. */
export const typeDuration = (text: string) => text.length * timings.typeCharMs;

export function CheckIcon({ size = 14, color = 'currentColor' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 14 14" aria-hidden>
      <path d="M2.8 7.3l2.7 2.7 5.7-6" fill="none" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
