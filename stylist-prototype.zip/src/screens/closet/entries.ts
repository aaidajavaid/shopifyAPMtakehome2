import {
  closetItems,
  products,
  type ClosetCategory,
  type ClosetItem,
  type Placeholder,
  type Product,
} from '../../data/demo';

/** One thing shown in the closet: a piece Jane owns, a Stylist pick
 *  previewed from her bag, or a new piece she just bought. */
export type Entry =
  | { id: string; kind: 'closet'; item: ClosetItem }
  | { id: string; kind: 'product'; product: Product; state: 'preview' | 'new' };

export function entryInfo(e: Entry): {
  name: string;
  folder: 'closet' | 'products';
  file: string;
  placeholder: Placeholder;
  category: ClosetCategory;
  pairsWith: string[];
} {
  if (e.kind === 'closet') {
    return {
      name: e.item.name,
      folder: 'closet',
      file: e.item.image,
      placeholder: e.item.placeholder,
      category: e.item.category,
      pairsWith: e.item.pairsWith,
    };
  }
  return {
    name: e.product.shortName,
    folder: 'products',
    file: e.product.image,
    placeholder: e.product.placeholder,
    category: e.product.closetSlot,
    pairsWith: e.product.pairsWith,
  };
}

interface ClosetState {
  outfitReady: boolean;
  showPicks: boolean;
  bag: string[];
  purchased: string[];
}

/** Stylist picks show first in each section so they're easy to spot. */
export function buildEntries(s: ClosetState): Entry[] {
  const bought = s.purchased.length > 0;
  const picks: Entry[] = products
    .filter((p) => (bought ? s.purchased.includes(p.id) : s.outfitReady && s.showPicks && s.bag.includes(p.id)))
    .map((p) => ({ id: p.id, kind: 'product', product: p, state: bought ? 'new' : 'preview' }));
  const owned: Entry[] = closetItems.map((item) => ({ id: item.id, kind: 'closet', item }));
  return [...picks, ...owned];
}

export function findEntry(entries: Entry[], id: string | null) {
  if (!id) return null;
  const hit = entries.find((e) => e.id === id);
  if (hit) return hit;
  // An item can be opened even if picks are hidden (e.g. from a pairing).
  const item = closetItems.find((c) => c.id === id);
  if (item) return { id, kind: 'closet', item } as Entry;
  const product = products.find((p) => p.id === id);
  if (product) return { id, kind: 'product', product, state: 'preview' } as Entry;
  return null;
}
