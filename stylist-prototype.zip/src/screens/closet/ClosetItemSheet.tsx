import { AnimatePresence, motion, useDragControls, type PanInfo } from 'framer-motion';
import {
  closetCopy as copy,
  closetDressUpLooks,
  closetItems,
  closetSize,
  merchants,
  productLooks,
  stylistLook,
  type Occasion,
} from '../../data/demo';
import { useAppState, useDispatch } from '../../state/store';
import { ItemImage } from '../../components/ItemImage';
import { OccasionTags } from '../../components/ui';
import { buildEntries, entryInfo, findEntry, type Entry } from './entries';

const fill = (t: string, vals: Record<string, string | number>) =>
  Object.entries(vals).reduce((s, [k, v]) => s.replace(`{${k}}`, String(v)), t);

/** Rendered at app level so it sits above the tab bar. */
export function ClosetItemSheet() {
  const { closetSheet, outfitReady, showPicks, bag, purchased } = useAppState();
  const entry = findEntry(buildEntries({ outfitReady, showPicks, bag, purchased }), closetSheet);
  const dispatch = useDispatch();
  const drag = useDragControls();
  const close = () => dispatch({ type: 'closetSheet', id: null });
  const onDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.y > 100 || info.velocity.y > 600) close();
  };

  return (
    <AnimatePresence>
      {entry && (
        <div className="sheetlayer" key="closet-sheet">
          <motion.div
            className="sheet-backdrop sheet-backdrop--light"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            onClick={close}
          />
          <motion.div
            className="sheet itemsheet"
            role="dialog"
            aria-modal="true"
            aria-label={entryInfo(entry).name}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 40 }}
            drag="y"
            dragListener={false}
            dragControls={drag}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.6 }}
            onDragEnd={onDragEnd}
          >
            <div className="sheet__grab" onPointerDown={(e) => drag.start(e)}>
              <div className="sheet__handle" />
            </div>
            <SheetBody key={entry.id} entry={entry} onClose={close} />
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

function SheetBody({ entry, onClose }: { entry: Entry; onClose: () => void }) {
  const dispatch = useDispatch();
  const info = entryInfo(entry);
  const pairs = info.pairsWith.map((id) => closetItems.find((c) => c.id === id)!).filter(Boolean);

  let line: string;
  let stat: string;
  let occasions: Occasion[];
  let tag: 'bag' | 'new' | null = null;
  if (entry.kind === 'closet') {
    line = copy.inClosetLine;
    stat = fill(copy.wornIn, { n: entry.item.wornInLooks });
    occasions = entry.item.occasions;
  } else {
    const merchant = merchants[entry.product.merchantId].name;
    line = fill(entry.state === 'new' ? copy.newLine : copy.previewLine, { merchant });
    stat = fill(copy.goesWith, { n: entry.product.closetMatches, total: closetSize });
    occasions = entry.product.occasions;
    tag = entry.state === 'new' ? 'new' : 'bag';
  }

  const look =
    entry.kind === 'closet' ? closetDressUpLooks[entry.id] : productLooks[entry.id] ?? stylistLook;
  const preview = entry.kind === 'product' && entry.state === 'preview';

  return (
    <div className="sheet__body">
      <div className="sheet__scroll scroll itemsheet__scroll">
        <div className="itemsheet__media">
          <ItemImage folder={info.folder} file={info.file} placeholder={info.placeholder} alt={info.name} className="itemsheet__img" inset={10} />
          {tag && <span className={'tile__tag tile__tag--' + tag + ' itemsheet__tag'}>{tag === 'new' ? copy.newTag : copy.inYourBag}</span>}
          <button className="iconbtn itemsheet__close" aria-label="Close" onClick={onClose}>
            <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden>
              <path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div className="itemsheet__line">{line}</div>
        <h2 className="itemsheet__name">{entry.kind === 'product' ? entry.product.name : info.name}</h2>
        <div className="itemsheet__stat">{stat}</div>
        <OccasionTags occasions={occasions} />

        {pairs.length > 0 && (
          <div className="itemsheet__pairs">
            <div className="section-label itemsheet__label">{copy.pairsWith}</div>
            <div className="pairs">
              {pairs.map((c) => (
                <button key={c.id} className="pair pair--btn" onClick={() => dispatch({ type: 'closetSheet', id: c.id })}>
                  <ItemImage folder="closet" file={c.image} placeholder={c.placeholder} alt="" className="pair__img" inset={10} />
                  <div className="pair__name">{c.name}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="sheet__footer sheet__footer--stack">
        {look && (
          <motion.button
            className="btn btn--primary btn--lg"
            whileTap={{ scale: 0.98 }}
            onClick={() => dispatch({ type: 'styleInDressUp', itemId: entry.kind === 'closet' ? entry.id : entry.product.id, look })}
          >
            {copy.styleInDressUp}
          </motion.button>
        )}
        {preview && (
          <motion.button className="btn btn--secondary btn--lg" whileTap={{ scale: 0.98 }} onClick={() => dispatch({ type: 'backToBag' })}>
            {copy.viewInBag}
          </motion.button>
        )}
      </div>
    </div>
  );
}
