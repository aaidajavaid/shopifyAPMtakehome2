import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useEffect, useMemo, useRef, useState } from 'react';
import { closetCopy as copy, closetItems, closetSections, type ClosetCategory } from '../../data/demo';
import { useAppState, useDispatch } from '../../state/store';
import { ItemImage } from '../../components/ItemImage';
import { ResetTitle } from '../../shell/ResetTitle';
import { buildEntries, entryInfo, findEntry, type Entry } from './entries';
import './closet.css';

const fill = (t: string, n: number | string) => t.replace('{n}', String(n));

export function ClosetScreen() {
  const state = useAppState();
  const { outfitReady, showPicks, bag, purchased, closetSheet, tab } = state;
  const dispatch = useDispatch();
  const reduce = useReducedMotion();
  const scrollRef = useRef<HTMLDivElement>(null);
  const headRef = useRef<HTMLDivElement>(null);
  const sectionRefs = useRef<Partial<Record<ClosetCategory, HTMLElement | null>>>({});
  const [active, setActive] = useState<ClosetCategory | 'all'>('all');
  const [flash, setFlash] = useState<{ id: ClosetCategory; n: number } | null>(null);
  const [glow, setGlow] = useState(0);
  // While a chip-triggered scroll is running, keep that chip selected.
  const lockUntil = useRef(0);

  const entries = useMemo(
    () => buildEntries({ outfitReady, showPicks, bag, purchased }),
    [outfitReady, showPicks, bag, purchased],
  );
  const bought = purchased.length > 0;
  const previewCount = entries.filter((e) => e.kind === 'product' && e.state === 'preview').length;
  const ownedCount = closetItems.length + purchased.length;

  // Pairings of the open item glow in the closet behind the sheet.
  const open = findEntry(entries, closetSheet);
  const pairIds = open ? entryInfo(open).pairsWith : [];

  // New pieces get a soft one-time highlight the first time Jane opens the
  // closet after checkout.
  useEffect(() => {
    if (bought && tab === 'closet' && glow === 0) setGlow(1);
  }, [bought, tab, glow]);

  // Keep the selected chip visible in the chip bar.
  const chipsRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const bar = chipsRef.current;
    const chip = bar?.querySelector<HTMLElement>('.cchip.is-on');
    if (!bar || !chip) return;
    const left = chip.offsetLeft - 16;
    const right = chip.offsetLeft + chip.offsetWidth + 16 - bar.clientWidth;
    if (bar.scrollLeft > left) bar.scrollTo({ left, behavior: reduce ? 'auto' : 'smooth' });
    else if (bar.scrollLeft < right) bar.scrollTo({ left: right, behavior: reduce ? 'auto' : 'smooth' });
  }, [active, reduce]);

  // ── Category chips: jump, and follow the scroll ──
  const jump = (id: ClosetCategory | 'all') => {
    const el = scrollRef.current;
    if (!el) return;
    const behavior: ScrollBehavior = reduce ? 'auto' : 'smooth';
    setActive(id);
    lockUntil.current = performance.now() + 900;
    if (id === 'all') {
      el.scrollTo({ top: 0, behavior });
      return;
    }
    const sec = sectionRefs.current[id];
    if (!sec) return;
    const headH = headRef.current?.offsetHeight ?? 0;
    const top = el.scrollTop + sec.getBoundingClientRect().top - el.getBoundingClientRect().top - headH - 10;
    el.scrollTo({ top, behavior });
    setFlash((f) => ({ id, n: (f?.n ?? 0) + 1 }));
  };

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el || performance.now() < lockUntil.current) return;
    const headBottom = el.getBoundingClientRect().top + (headRef.current?.offsetHeight ?? 0) + 24;
    let current: ClosetCategory | 'all' = 'all';
    for (const s of closetSections) {
      const sec = sectionRefs.current[s.id];
      if (sec && sec.getBoundingClientRect().top <= headBottom) current = s.id;
    }
    if (el.scrollTop + el.clientHeight >= el.scrollHeight - 4) current = 'accessories';
    setActive(current);
  };

  const tileProps = (e: Entry) => ({
    entry: e,
    pair: pairIds.includes(e.id),
    glow: glow > 0 && e.kind === 'product' && e.state === 'new',
    onOpen: () => dispatch({ type: 'closetSheet', id: e.id }),
  });

  const inSection = (id: ClosetCategory) => entries.filter((e) => entryInfo(e).category === id);

  return (
    <div className="closet">
      <div ref={scrollRef} className="scroll closet__scroll" onScroll={onScroll}>
        <div ref={headRef} className="closet__head">
          <div className="closet__titlerow">
            <ResetTitle>
              <h1 className="closet__title">{copy.title}</h1>
              <div className="closet__count">
                {fill(copy.count, ownedCount)}
                {previewCount > 0 && <span className="closet__countbag"> · {fill(copy.inBagCount, previewCount)}</span>}
              </div>
            </ResetTitle>
            <motion.button
              className="addbtn"
              aria-label="Add a piece"
              whileTap={{ scale: 0.9 }}
              onClick={() => dispatch({ type: 'toast', text: copy.addSoon })}
            >
              <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden>
                <path d="M8 2.5v11M2.5 8h11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </motion.button>
          </div>

          <div ref={chipsRef} className="cchips scroll-x" role="tablist" aria-label="Categories">
            {(['all', ...closetSections.map((s) => s.id)] as (ClosetCategory | 'all')[]).map((id) => {
              const label = id === 'all' ? copy.all : closetSections.find((s) => s.id === id)!.label;
              const on = active === id;
              return (
                <button key={id} role="tab" aria-selected={on} className={'cchip' + (on ? ' is-on' : '')} onClick={() => jump(id)}>
                  {on && <motion.span layoutId="cchip-pill" className="cchip__pill" transition={{ type: 'spring', stiffness: 500, damping: 38 }} />}
                  <span className="cchip__label">{label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <AnimatePresence initial={false}>
          {outfitReady && !bought && (
            <motion.div
              className="picks"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ type: 'spring', stiffness: 380, damping: 40 }}
            >
              <div className="picks__inner">
                <div>
                  <div className="picks__title">{copy.showPicks}</div>
                  <div className="picks__note">{copy.showPicksNote}</div>
                </div>
                <button
                  role="switch"
                  aria-checked={showPicks}
                  aria-label={copy.showPicks}
                  className={'switch' + (showPicks ? ' is-on' : '')}
                  onClick={() => dispatch({ type: 'togglePicks' })}
                >
                  <motion.span className="switch__knob" layout transition={{ type: 'spring', stiffness: 600, damping: 34 }} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="cabinet">
          <div className="cabinet__crown" aria-hidden />
          {closetSections.map((sec) => {
            const items = inSection(sec.id);
            const flashing = flash?.id === sec.id;
            return (
              <section
                key={sec.id}
                ref={(el) => {
                  sectionRefs.current[sec.id] = el;
                }}
                className={`csec csec--${sec.kind}`}
                aria-label={sec.label}
              >
                {flashing && <motion.div key={flash!.n} className="csec__flash" initial={{ opacity: 0.9 }} animate={{ opacity: 0 }} transition={{ duration: 1.4, ease: 'easeOut' }} />}
                <div className="csec__label">{sec.label}</div>

                {sec.kind === 'rail' && (
                  <div className="rail">
                    <div className="rail__bar" aria-hidden />
                    <div className="rail__row scroll-x">
                      <AnimatePresence initial={false}>
                        {items.map((e) => (
                          <Tile key={e.id} {...tileProps(e)} variant="hang" />
                        ))}
                      </AnimatePresence>
                    </div>
                  </div>
                )}

                {sec.kind === 'shelf' && (
                  <div className="shelf">
                    <div className="shelf__row">
                      <AnimatePresence initial={false}>
                        {items.map((e) => (
                          <Tile key={e.id} {...tileProps(e)} variant="fold" />
                        ))}
                      </AnimatePresence>
                    </div>
                    <div className="plank" aria-hidden />
                  </div>
                )}

                {sec.kind === 'rack' && (
                  <div className="rack">
                    <div className="shelf__row">
                      <AnimatePresence initial={false}>
                        {items.map((e) => (
                          <Tile key={e.id} {...tileProps(e)} variant="shoe" />
                        ))}
                      </AnimatePresence>
                    </div>
                    <div className="rack__bars" aria-hidden>
                      <span />
                      <span />
                    </div>
                  </div>
                )}

                {sec.kind === 'tray' && (
                  <div className="tray">
                    <div className="shelf__row">
                      <AnimatePresence initial={false}>
                        {items.map((e) => (
                          <Tile key={e.id} {...tileProps(e)} variant="fold" />
                        ))}
                      </AnimatePresence>
                    </div>
                  </div>
                )}
              </section>
            );
          })}
          <div className="cabinet__base" aria-hidden />
        </div>
      </div>
    </div>
  );
}

/* ─── Tile ─────────────────────────────────────────────────────────────── */

function Tile({
  entry,
  variant,
  pair,
  glow,
  onOpen,
}: {
  entry: Entry;
  variant: 'hang' | 'fold' | 'shoe';
  pair: boolean;
  glow: boolean;
  onOpen: () => void;
}) {
  const info = entryInfo(entry);
  const preview = entry.kind === 'product' && entry.state === 'preview';
  const isNew = entry.kind === 'product' && entry.state === 'new';
  const cls = ['tile', `tile--${variant}`, preview && 'is-preview', isNew && 'is-new', pair && 'is-pair', glow && 'is-glow']
    .filter(Boolean)
    .join(' ');

  return (
    <motion.button
      layout
      className={cls}
      onClick={onOpen}
      aria-label={`${info.name}${preview ? ', in your bag' : isNew ? ', new' : ''}`}
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.85 }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 420, damping: 30 }}
    >
      {variant === 'hang' && (
        <svg className="tile__hanger" width="56" height="20" viewBox="0 0 56 20" aria-hidden>
          <path d="M28 7.5a3.4 3.4 0 1 0-3.4-3.4" fill="none" stroke="#9C8566" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M28 7.5 6 18h44Z" fill="none" stroke="#9C8566" strokeWidth="1.6" strokeLinejoin="round" />
        </svg>
      )}
      <div className="tile__card">
        <ItemImage folder={info.folder} file={info.file} placeholder={info.placeholder} alt="" className="tile__img" inset={variant === 'shoe' ? 6 : 8} />
        {preview && <span className="tile__tag tile__tag--bag">{copy.inYourBag}</span>}
        {isNew && <span className="tile__tag tile__tag--new">{copy.newTag}</span>}
      </div>
      <div className="tile__name">{info.name}</div>
    </motion.button>
  );
}
