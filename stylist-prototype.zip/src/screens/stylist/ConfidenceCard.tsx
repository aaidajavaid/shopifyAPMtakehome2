import { AnimatePresence, motion } from 'framer-motion';
import type { ReactNode } from 'react';
import { closetItems, closetSize, type Product } from '../../data/demo';
import { useAppState, useDispatch } from '../../state/store';
import { ItemImage } from '../../components/ItemImage';
import { ScoreRing, matchPercent, scoreBand } from '../../components/ui';

/** Closet-match ring that sits in the empty corner of the product photo. */
export function MatchBadge({ product }: { product: Product }) {
  const pct = matchPercent(product.closetMatches, closetSize);
  return <ScoreBadge value={pct} label="Closet match" />;
}

/** Shared ring badge: "Closet match" in Stylist, "Style match" in Dress Up. */
export function ScoreBadge({ value, label, className }: { value: number; label: string; className?: string }) {
  return (
    <div className={'matchbadge ' + (className ?? '')} aria-label={`${label}: ${value} percent`}>
      <ScoreRing value={value} size={46} stroke={4.5} />
      <span className="matchbadge__label">{label}</span>
    </div>
  );
}

/** "Does this work for my life and my closet?" Collapsed to a single pill
 *  by default; only one is open at a time. */
export function ConfidenceCard({ product, actions }: { product: Product; actions?: ReactNode }) {
  const { openConfidenceId } = useAppState();
  const dispatch = useDispatch();
  const open = openConfidenceId === product.id;
  const pct = matchPercent(product.closetMatches, closetSize);
  const pairs = product.pairsWith.map((id) => closetItems.find((c) => c.id === id)!);
  const panelId = `why-${product.id}`;
  const band = scoreBand(pct);

  return (
    <div className={'conf' + (open ? ' is-open' : '')}>
      <div className="conf__togglerow">
        <motion.button
          className={'conf__toggle' + (open ? ' is-open' : '')}
          aria-expanded={open}
          aria-controls={panelId}
          whileTap={{ scale: 0.96 }}
          onClick={() => dispatch({ type: 'toggleConfidence', id: product.id })}
        >
          <svg width="13" height="13" viewBox="0 0 10 10" aria-hidden>
            <path d="M5 0l1.3 3.7L10 5 6.3 6.3 5 10 3.7 6.3 0 5l3.7-1.3z" fill="currentColor" />
          </svg>
          {open ? 'Less' : 'Why this works'}
          <motion.svg
            width="12"
            height="12"
            viewBox="0 0 12 12"
            aria-hidden
            animate={{ rotate: open ? 180 : 0 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
          >
            <path d="M2.5 4.5L6 8l3.5-3.5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          </motion.svg>
        </motion.button>
        {actions && <div className="conf__actions">{actions}</div>}
      </div>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            id={panelId}
            key="panel"
            className="conf__panel"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ height: { type: 'spring', stiffness: 380, damping: 40 }, opacity: { duration: 0.2 } }}
          >
            <div className="conf__panelinner">
              <div className="conf__lead">
                <div className="conf__headline">
                  Goes with <span style={{ color: band.color }}>{pct}%</span> of your closet
                </div>
                <div className="conf__reason">{product.reason}</div>
              </div>
              <div className="conf__section">
                <div className="conf__label">
                  Pairs with <span className="conf__labelnote">{product.closetMatches} of {closetSize} pieces</span>
                </div>
                <div className="pairs">
                  {pairs.map((c, i) => (
                    <motion.div
                      key={c.id}
                      className="pair"
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ type: 'spring', stiffness: 400, damping: 30, delay: 0.06 + i * 0.05 }}
                    >
                      <ItemImage folder="closet" file={c.image} placeholder={c.placeholder} alt={c.name} className="pair__img" inset={10} />
                      <div className="pair__name">{c.name}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="conf__section">
                <div className="conf__label">From shoppers like you</div>
                <ul className="proof">
                  <li>
                    <ProofIcon kind="kept" />
                    {product.socialProof.lines[0]}
                  </li>
                  <li>
                    <ProofIcon kind="reviews" />
                    {product.socialProof.lines[1]}
                  </li>
                </ul>
                <figure className="quote">
                  <blockquote>{'“' + product.socialProof.quote.text + '”'}</blockquote>
                  <figcaption>
                    {product.socialProof.quote.name}, {product.socialProof.quote.role}
                  </figcaption>
                </figure>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

function ProofIcon({ kind }: { kind: 'kept' | 'reviews' }) {
  if (kind === 'kept') {
    return (
      <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden className="proof__icon">
        <circle cx="8" cy="8" r="7" fill="#E1EFE5" />
        <path d="M4.8 8.2l2.1 2.1 4.3-4.6" fill="none" stroke="#3E8A5C" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden className="proof__icon">
      <circle cx="8" cy="8" r="7" fill="#E1EFE5" />
      <path d="M8 4.2l1.1 2.3 2.5.3-1.8 1.7.5 2.5L8 9.8 5.7 11l.5-2.5-1.8-1.7 2.5-.3z" fill="#3E8A5C" />
    </svg>
  );
}
