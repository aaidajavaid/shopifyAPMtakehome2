import { AnimatePresence, motion } from 'framer-motion';
import { merchants, type Product } from '../../data/demo';
import { useAppState, useDispatch } from '../../state/store';
import { ItemImage } from '../../components/ItemImage';
import { CheckIcon, OccasionTags, formatPrice } from '../../components/ui';
import { ConfidenceCard, MatchBadge } from './ConfidenceCard';

/** Compact product card: the photo carries the closet match and occasion
 *  tags, the body carries merchant, name and price, and one row holds
 *  "Why this works" plus the two actions. */
export function ProductCard({ product }: { product: Product }) {
  const { bag, purchased } = useAppState();
  const ordered = purchased.includes(product.id);
  const dispatch = useDispatch();
  const merchant = merchants[product.merchantId];
  const inBag = bag.includes(product.id);

  const actions = (
    <>
      <motion.button
        className="minibtn minibtn--ghost"
        aria-label={`View ${product.shortName} in Dress Up`}
        whileTap={{ scale: 0.95 }}
        onClick={() => dispatch({ type: 'viewInDressUp', productId: product.id })}
      >
        Try on
      </motion.button>
      <motion.button
        className={'minibtn ' + (ordered ? 'minibtn--ordered' : inBag ? 'minibtn--inbag' : 'minibtn--primary')}
        whileTap={ordered ? undefined : { scale: 0.95 }}
        disabled={ordered || (purchased.length > 0 && !inBag)}
        aria-pressed={inBag}
        aria-label={ordered ? 'Ordered' : inBag ? 'In bag, tap to remove' : 'Add to bag'}
        onClick={() => dispatch({ type: 'toggleBag', id: product.id })}
      >
        <AnimatePresence mode="wait" initial={false}>
          <motion.span
            key={ordered ? 'ordered' : inBag ? 'in' : 'add'}
            className="btn__inner"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.14 }}
          >
            {ordered ? (
              <>
                Ordered <CheckIcon size={12} />
              </>
            ) : inBag ? (
              <>
                In bag <CheckIcon size={12} />
              </>
            ) : (
              'Add to bag'
            )}
          </motion.span>
        </AnimatePresence>
      </motion.button>
    </>
  );

  return (
    <article className="pcard" aria-label={product.name}>
      <div className="pcard__media">
        <ItemImage folder="products" file={product.image} placeholder={product.placeholder} alt={product.name} className="pcard__img" inset={8} />
        <div className="pcard__tags">
          <OccasionTags occasions={product.occasions} />
        </div>
        <MatchBadge product={product} />
      </div>

      <div className="pcard__body">
        <div className="pcard__meta">
          <span className="pcard__merchant">{merchant.name}</span>
          <a className="pcard__link" href={merchant.url} target="_blank" rel="noopener noreferrer">
            View product
            <svg width="8" height="8" viewBox="0 0 9 9" aria-hidden>
              <path d="M2 7l5-5M3 2h4v4" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>
        </div>
        <div className="pcard__titlerow">
          <h3 className="pcard__name">{product.name}</h3>
          <span className="pcard__price">{formatPrice(product.price)}</span>
        </div>
      </div>

      <ConfidenceCard product={product} actions={actions} />
    </article>
  );
}
