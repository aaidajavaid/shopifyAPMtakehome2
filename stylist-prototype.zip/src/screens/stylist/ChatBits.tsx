import { AnimatePresence, motion } from 'framer-motion';
import { CheckIcon, TypedText, spring } from '../../components/ui';

const enter = {
  initial: { opacity: 0, y: 10, scale: 0.98 },
  animate: { opacity: 1, y: 0, scale: 1 },
  transition: spring,
};

export function AgentBubble({ text, typed, tone }: { text: string; typed?: boolean; tone?: 'note' }) {
  return (
    <motion.div className="msg msg--agent" {...enter} style={{ transformOrigin: 'left bottom' }}>
      <div className={'bubble bubble--agent' + (tone === 'note' ? ' bubble--note' : '')}>
        {typed ? <TypedText text={text} /> : text}
      </div>
    </motion.div>
  );
}

export function UserBubble({ text }: { text: string }) {
  return (
    <motion.div className="msg msg--user" {...enter} style={{ transformOrigin: 'right bottom' }}>
      <div className="bubble bubble--user">{text}</div>
    </motion.div>
  );
}

export function ThinkingBubble() {
  return (
    <motion.div className="msg msg--agent" {...enter} style={{ transformOrigin: 'left bottom' }}>
      <div className="bubble bubble--agent bubble--thinking" aria-label="Stylist is typing">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="dot"
            animate={{ opacity: [0.3, 1, 0.3], y: [0, -2, 0] }}
            transition={{ duration: 1, repeat: Infinity, delay: i * 0.16, ease: 'easeInOut' }}
          />
        ))}
      </div>
    </motion.div>
  );
}

/** "Shows its work": each step appears, spins, then turns into a check. */
export function StepsCard({ steps, done }: { steps: string[]; done: number }) {
  const visible = Math.min(steps.length, done + 1);
  return (
    <motion.div className="msg msg--agent" {...enter} style={{ transformOrigin: 'left top' }}>
      <div className="steps" role="status" aria-live="polite">
        <AnimatePresence initial={false}>
          {steps.slice(0, visible).map((label, i) => {
            const complete = i < done;
            return (
              <motion.div
                key={label}
                className={'step' + (complete ? ' is-done' : '')}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                transition={{ ...spring, opacity: { duration: 0.2 } }}
              >
                <div className="step__inner">
                  <span className="step__icon">
                    <AnimatePresence mode="popLayout" initial={false}>
                      {complete ? (
                        <motion.span
                          key="check"
                          className="step__check"
                          initial={{ scale: 0.4, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          transition={{ type: 'spring', stiffness: 600, damping: 22 }}
                        >
                          <CheckIcon size={12} color="#fff" />
                        </motion.span>
                      ) : (
                        <motion.span
                          key="spin"
                          className="step__spinner"
                          exit={{ scale: 0.5, opacity: 0, transition: { duration: 0.12 } }}
                          animate={{ rotate: 360 }}
                          transition={{ rotate: { duration: 0.9, repeat: Infinity, ease: 'linear' } }}
                        />
                      )}
                    </AnimatePresence>
                  </span>
                  <span className="step__label">{complete ? label.replace(/…$/, '') : label}</span>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export function Chips({
  chips,
  onPick,
}: {
  chips: { id: string; label: string }[];
  onPick: (id: string) => void;
}) {
  return (
    <div className="chips" role="group" aria-label="Suggestions">
      {chips.map((c, i) => (
        <motion.button
          key={c.id}
          className="chip"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...spring, delay: i * 0.06 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => onPick(c.id)}
        >
          {c.label}
        </motion.button>
      ))}
    </div>
  );
}
