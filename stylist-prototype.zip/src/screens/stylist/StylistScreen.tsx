import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useReducedMotion } from 'framer-motion';
import { stylistCopy as copy, timings } from '../../data/demo';
import { useAppState, useDispatch, type ChatEvent } from '../../state/store';
import { typeDuration } from '../../components/ui';
import { ResetTitle } from '../../shell/ResetTitle';
import { AgentBubble, Chips, StepsCard, ThinkingBubble, UserBubble } from './ChatBits';
import { OutfitBlock } from './OutfitBlock';
import './stylist.css';

/** Small timer helper. Every pending step is cancelled on unmount (which is
 *  also how the demo reset stops a flow mid-way). */
function useScheduler() {
  const timers = useRef<number[]>([]);
  useEffect(
    () => () => {
      timers.current.forEach((t) => window.clearTimeout(t));
      timers.current = [];
    },
    [],
  );
  return useCallback((ms: number, fn: () => void) => {
    timers.current.push(window.setTimeout(fn, ms));
  }, []);
}

export function StylistScreen() {
  const { chat, chips, bagFocus } = useAppState();
  const dispatch = useDispatch();
  const schedule = useScheduler();
  const reduce = useReducedMotion();
  const scrollRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLElement>(null);
  const anchorRef = useRef<HTMLDivElement>(null);
  const [viewportH, setViewportH] = useState(0);
  const idSeq = useRef(0);
  const nextId = () => `e${++idSeq.current}`;

  // ── Opening message ──
  useEffect(() => {
    const timers: number[] = [];
    timers.push(
      window.setTimeout(() => {
        dispatch({ type: 'pushChat', event: { id: 'greeting', kind: 'agent', text: copy.greeting } });
      }, timings.greetingDelay),
    );
    timers.push(
      window.setTimeout(
        () => dispatch({ type: 'setChips', chips: 'initial' }),
        timings.greetingDelay + typeDuration(copy.greeting) + timings.chipsAfterGreeting,
      ),
    );
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [dispatch]);

  // Track the visible height so the work flow can scroll its first message to the top.
  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setViewportH(el.clientHeight));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // ── Auto-scroll ──
  const anchorIndex = chat.findIndex((e) => e.kind === 'user' && e.anchor);
  const lastId = chat[chat.length - 1]?.id;
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !lastId) return;
    const behavior: ScrollBehavior = reduce ? 'auto' : 'smooth';
    const last = chat[chat.length - 1];
    if (anchorIndex >= 0) {
      // Work flow: pin Jane's message under the header once; the steps,
      // reply and cards then unfold below it without the view jumping.
      if (last.kind === 'user' && last.anchor && anchorRef.current) {
        const headerH = headerRef.current?.offsetHeight ?? 0;
        requestAnimationFrame(() => {
          el.scrollTo({ top: anchorRef.current!.offsetTop - headerH - 12, behavior });
        });
      }
      return;
    }
    requestAnimationFrame(() => el.scrollTo({ top: el.scrollHeight, behavior }));
  }, [lastId, chips]);

  // "Back to bag" from Dress Up: bring the bag summary into view.
  useEffect(() => {
    if (!bagFocus) return;
    const el = scrollRef.current;
    const bag = el?.querySelector<HTMLElement>('.bag');
    if (!el || !bag) return;
    // Land with the whole bag (and its Shop Pay button) visible above the tab bar.
    const delta = bag.getBoundingClientRect().bottom - el.getBoundingClientRect().bottom;
    el.scrollTo({ top: el.scrollTop + delta + 100, behavior: 'auto' });
  }, [bagFocus]);

  // ── Chip taps ──
  const onChip = (chipId: string) => {
    const chip = copy.chips.find((c) => c.id === chipId)!;
    dispatch({ type: 'setChips', chips: null });

    if (chipId !== copy.workChipId) {
      // Not part of the demo flow yet: a warm reply that steers back.
      const reply = copy.comingSoonReplies[chipId];
      const thinkingId = nextId();
      dispatch({ type: 'pushChat', event: { id: nextId(), kind: 'user', text: chip.label } });
      schedule(timings.userToAgent, () =>
        dispatch({ type: 'pushChat', event: { id: thinkingId, kind: 'thinking' } }),
      );
      schedule(timings.userToAgent + timings.thinking, () =>
        dispatch({ type: 'replaceChat', id: thinkingId, event: { id: thinkingId, kind: 'agent', text: reply } }),
      );
      schedule(timings.userToAgent + timings.thinking + typeDuration(reply) + timings.chipsAfterGreeting, () =>
        dispatch({ type: 'setChips', chips: 'retry' }),
      );
      return;
    }

    // ── The work outfit flow ──
    const stepsId = nextId();
    dispatch({ type: 'pushChat', event: { id: nextId(), kind: 'user', text: chip.label, anchor: true } });

    let t = timings.userToAgent;
    schedule(t, () => dispatch({ type: 'pushChat', event: { id: stepsId, kind: 'steps', done: 0 } }));

    // ── SIMULATED: Shopify Catalog API ──
    // In production: agent queries Shopify Catalog for products matching
    // occasion=workwear, budget, and closet compatibility.
    t += timings.stepMs;
    schedule(t, () => dispatch({ type: 'stepsDone', id: stepsId, done: 1 }));

    // ── SIMULATED: Closet compatibility model ──
    // In production: each candidate is scored against Jane's 13 closet items
    // (colour, formality, silhouette) to produce "goes with X of 13 pieces",
    // and items that duplicate what she owns (a new top) are dropped.
    t += timings.stepMs;
    schedule(t, () => dispatch({ type: 'stepsDone', id: stepsId, done: 2 }));

    // Styling step: assembles the look around her striped button-up.
    t += timings.stepMs;
    schedule(t, () => dispatch({ type: 'stepsDone', id: stepsId, done: 3 }));

    t += timings.afterSteps;
    schedule(t, () => dispatch({ type: 'pushChat', event: { id: nextId(), kind: 'agent', text: copy.outfitReply } }));

    t += typeDuration(copy.outfitReply) + timings.afterReply;
    schedule(t, () => {
      dispatch({ type: 'pushChat', event: { id: nextId(), kind: 'outfit' } });
      dispatch({ type: 'outfitReady' });
    });
  };

  const renderEvent = (e: ChatEvent) => {
    switch (e.kind) {
      case 'agent':
        return <AgentBubble key={e.id} text={e.text} typed />;
      case 'user':
        return <UserBubble key={e.id} text={e.text} />;
      case 'thinking':
        return <ThinkingBubble key={e.id} />;
      case 'steps':
        return <StepsCard key={e.id} steps={copy.steps} done={e.done} />;
      case 'outfit':
        return <OutfitBlock key={e.id} />;
    }
  };

  const headerH = headerRef.current?.offsetHeight ?? 0;
  const before = anchorIndex >= 0 ? chat.slice(0, anchorIndex) : chat;
  const after = anchorIndex >= 0 ? chat.slice(anchorIndex) : [];

  return (
    <div ref={scrollRef} className="scroll stylist">
      <header ref={headerRef} className="stylist__header">
        <ResetTitle className="stylist__id">
          <div className="stylist__mark" aria-hidden>
            <span>S</span>
            <svg className="stylist__spark" width="10" height="10" viewBox="0 0 10 10">
              <path d="M5 0l1.3 3.7L10 5 6.3 6.3 5 10 3.7 6.3 0 5l3.7-1.3z" fill="currentColor" />
            </svg>
          </div>
          <div className="stylist__titles">
            <div className="stylist__name">{copy.name}</div>
            <div className="stylist__sub">{copy.subtitle}</div>
          </div>
        </ResetTitle>
      </header>

      <div className="chat">
        <div className="chat__day">Today</div>
        {before.map(renderEvent)}
        {chips === 'initial' && <Chips chips={copy.chips} onPick={onChip} />}
        {chips === 'retry' && (
          <Chips chips={copy.chips.filter((c) => c.id === copy.workChipId)} onPick={onChip} />
        )}
        {after.length > 0 && (
          <div className="chat__flow" style={{ minHeight: Math.max(0, viewportH - headerH - 24) }}>
            <div ref={anchorRef}>{renderEvent(after[0])}</div>
            {after.slice(1).map(renderEvent)}
          </div>
        )}
      </div>
    </div>
  );
}
