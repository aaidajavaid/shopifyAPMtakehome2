import { AnimatePresence, motion } from 'framer-motion';
import { checkoutCopy, products, stylistCopy as copy } from '../../data/demo';
import { useAppState, useDispatch } from '../../state/store';
import { ItemImage } from '../../components/ItemImage';
import { CheckIcon, formatPrice } from '../../components/ui';

export function BagSummary() {
  const { bag, purchased } = useAppState();
  const ordered = purchased.length > 0;
  const dispatch = useDispatch();
  const items = products.filter((p) => bag.includes(p.id));
  const subtotal = items.reduce((s, p) => s + p.price, 0);
  const empty = items.length === 0;

  return (
    <section className="bag" aria-label={copy.bagTitle}>
      <div className="bag__head">
        <div>
          <div className="bag__title">{ordered ? checkoutCopy.orderTitle : copy.bagTitle}</div>
          <div className="bag__count">
            {items.length} {items.length === 1 ? 'item' : 'items'}
          </div>
        </div>
        <div className="bag__thumbs" aria-hidden>
          <AnimatePresence initial={false}>
            {items.map((p) => (
              <motion.div
                key={p.id}
                layout
                className="bag__thumb"
                initial={{ opacity: 0, scale: 0.6 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.6 }}
                transition={{ type: 'spring', stiffness: 500, damping: 32 }}
              >
                <ItemImage folder="products" file={p.image} placeholder={p.placeholder} alt="" inset={8} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      <div className="bag__row">
        <span>Subtotal</span>
        <span className="bag__amount">
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.span
              key={subtotal}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ type: 'spring', stiffness: 500, damping: 34 }}
              style={{ display: 'inline-block' }}
            >
              {formatPrice(subtotal)}
            </motion.span>
          </AnimatePresence>
        </span>
      </div>
      {!ordered && <div className="bag__note">{copy.shippingNote}</div>}

      {ordered ? (
        <div className="bag__ordered">
          <span className="bag__orderedcheck">
            <CheckIcon size={12} color="#fff" />
          </span>
          <div>
            <div className="bag__orderedtitle">{checkoutCopy.ordered}</div>
            <div className="bag__orderednote">{checkoutCopy.orderedNote}</div>
          </div>
        </div>
      ) : (
        <>
      <motion.button
          className="shoppay-btn"
          whileTap={empty ? undefined : { scale: 0.98 }}
          disabled={empty}
          aria-label="Check out with Shop Pay"
          onClick={() => dispatch({ type: 'checkout', stage: 'review' })}
        >
          <span className="shoppay-btn__pre">Buy with</span>
          <span className="shoppay-btn__mark">Shop Pay</span>
        </motion.button>
        {empty && <div className="bag__empty">Add a piece to check out.</div>}
        </>
      )}
    </section>
  );
}
