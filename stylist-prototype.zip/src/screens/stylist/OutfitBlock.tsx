import { motion } from 'framer-motion';
import type { ReactNode } from 'react';
import { products, timings } from '../../data/demo';
import { ProductCard } from './ProductCard';
import { BagSummary } from './BagSummary';

function Rise({ i, children }: { i: number; children: ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30, delay: (i * timings.cardStagger) / 1000 }}
    >
      {children}
    </motion.div>
  );
}

const merchantCount = new Set(products.map((p) => p.merchantId)).size;

/** The outfit: the new pieces and the bag. */
export function OutfitBlock() {
  const n = products.length;
  return (
    <div className="outfit">
      <Rise i={0}>
        <div className="outfit__label">
          <span>Your look</span>
          <span className="outfit__count">From {merchantCount} Shopify merchants</span>
        </div>
      </Rise>

      {products.map((p, i) => (
        <Rise key={p.id} i={i + 1}>
          <ProductCard product={p} />
        </Rise>
      ))}

      <Rise i={n + 1}>
        <BagSummary />
      </Rise>
    </div>
  );
}
