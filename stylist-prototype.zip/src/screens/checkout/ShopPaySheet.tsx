import { AnimatePresence, motion, useDragControls, type PanInfo } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import { checkoutCopy as copy, checkoutTimings as T, merchants, products } from '../../data/demo';
import { useAppState, useDispatch } from '../../state/store';
import { ItemImage } from '../../components/ItemImage';
import { CheckIcon, formatPrice } from '../../components/ui';
import { FaceIdHud } from './FaceIdHud';
import './checkout.css';

/** Groups the bag by merchant, in first-seen order. */
function useOrder() {
  const { bag } = useAppState();
  const items = products.filter((p) => bag.includes(p.id));
  const groups: { merchantId: string; items: typeof items }[] = [];
  for (const p of items) {
    const g = groups.find((x) => x.merchantId === p.merchantId);
    if (g) g.items.push(p);
    else groups.push({ merchantId: p.merchantId, items: [p] });
  }
  const subtotal = items.reduce((s, p) => s + p.price, 0);
  const tax = Math.round(subtotal * copy.taxRate * 100) / 100;
  return { items, groups, subtotal, tax, total: subtotal + copy.shipping + tax };
}

const fill = (template: string, n: number) => template.replace('{n}', String(n));

export function ShopPaySheet() {
  const { checkout } = useAppState();
  const dispatch = useDispatch();
  const order = useOrder();
  const drag = useDragControls();
  const open = checkout !== 'closed';
  const canDismiss = checkout === 'review';

  const close = () => canDismiss && dispatch({ type: 'checkout', stage: 'closed' });
  const onDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.y > 120 || info.velocity.y > 600) close();
  };

  return (
    <AnimatePresence>
      {open && (
        <div className="sheetlayer" key="shoppay">
          <motion.div
            className="sheet-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={close}
          />
          <motion.div
            className="sheet shoppay"
            role="dialog"
            aria-modal="true"
            aria-label={copy.sheetTitle}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 40 }}
            drag={canDismiss ? 'y' : false}
            dragListener={false}
            dragControls={drag}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.6 }}
            onDragEnd={onDragEnd}
          >
            <div className="sheet__grab" onPointerDown={(e) => canDismiss && drag.start(e)}>
              <div className="sheet__handle" />
              <div className="shoppay__head">
                <span className="shoppay__mark">{copy.sheetTitle}</span>
                {canDismiss && (
                  <button className="iconbtn" aria-label="Close checkout" onClick={close}>
                    <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden>
                      <path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                    </svg>
                  </button>
                )}
              </div>
            </div>

            <AnimatePresence mode="wait" initial={false}>
              {(checkout === 'review' || checkout === 'faceid') && <Review key="review" order={order} />}
              {checkout === 'processing' && <Processing key="processing" order={order} />}
              {checkout === 'success' && <Success key="success" orders={order.groups.length} />}
            </AnimatePresence>
          </motion.div>

          <AnimatePresence>{checkout === 'faceid' && <FaceIdHud key="faceid" />}</AnimatePresence>
        </div>
      )}
    </AnimatePresence>
  );
}

const fade = {
  initial: { opacity: 0, y: 8 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
  transition: { duration: 0.2 },
};

/* ─── Review ───────────────────────────────────────────────────────────── */

function Review({ order }: { order: ReturnType<typeof useOrder> }) {
  const { checkout } = useAppState();
  const dispatch = useDispatch();
  const timers = useRef<number[]>([]);
  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  const pay = () => {
    dispatch({ type: 'checkout', stage: 'faceid' });
    timers.current.push(
      window.setTimeout(() => dispatch({ type: 'checkout', stage: 'processing' }), T.faceIdScanMs + T.faceIdCheckMs),
    );
  };

  return (
    <motion.div className="sheet__body" {...fade}>
      <div className="sheet__scroll scroll">
        <div className="sp-group">
          <Row label={copy.contactLabel} icon="pin">
            <div className="sp-strong">{copy.contactName}</div>
            <div className="sp-sub">{copy.shipTo}</div>
          </Row>
          <Row label={copy.paymentLabel} icon="card">
            <div className="sp-strong sp-card">
              <span className="visa" aria-hidden>VISA</span>
              {copy.payment}
            </div>
          </Row>
        </div>

        <div className="sp-label">{copy.orderLabel}</div>
        <div className="sp-group">
          {order.groups.map((g) => (
            <div className="sp-merchant" key={g.merchantId}>
              <div className="sp-merchant__name">
                <span className="sp-merchant__dot" aria-hidden />
                {merchants[g.merchantId].name}
              </div>
              {g.items.map((p) => (
                <div className="sp-item" key={p.id}>
                  <ItemImage folder="products" file={p.image} placeholder={p.placeholder} alt="" className="sp-item__img" inset={8} />
                  <div className="sp-item__name">{p.name}</div>
                  <div className="sp-item__price">{formatPrice(p.price)}</div>
                </div>
              ))}
            </div>
          ))}
        </div>

        <div className="sp-totals">
          <div className="sp-line">
            <span>Subtotal</span>
            <span>{formatPrice(order.subtotal)}</span>
          </div>
          <div className="sp-line">
            <span>Shipping</span>
            <span>{copy.shipping ? formatPrice(copy.shipping) : copy.shippingLabel}</span>
          </div>
          <div className="sp-line">
            <span>{copy.taxLabel}</span>
            <span>{formatPrice(order.tax)}</span>
          </div>
          <div className="sp-line sp-line--total">
            <span>Total</span>
            <span>
              <small>CAD</small> {formatPrice(order.total)}
            </span>
          </div>
        </div>

        <div className="sp-protocol">
          <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden>
            <circle cx="3.5" cy="7" r="2" fill="currentColor" />
            <circle cx="10.5" cy="3.5" r="2" fill="currentColor" />
            <circle cx="10.5" cy="10.5" r="2" fill="currentColor" />
            <path d="M5.2 6.2l3.6-1.9M5.2 7.8l3.6 1.9" stroke="currentColor" strokeWidth="1.1" />
          </svg>
          {fill(copy.protocolLine, order.groups.length)}
        </div>
      </div>

      <div className="sheet__footer">
        <motion.button
          className="shoppay-btn shoppay-btn--pay"
          whileTap={{ scale: 0.98 }}
          onClick={pay}
          disabled={checkout !== 'review'}
        >
          {copy.payNow}
          <span className="shoppay-btn__total">{formatPrice(order.total)}</span>
        </motion.button>
      </div>
    </motion.div>
  );
}

function Row({ label, icon, children }: { label: string; icon: 'pin' | 'card'; children: React.ReactNode }) {
  return (
    <div className="sp-row">
      <span className="sp-row__icon" aria-hidden>
        {icon === 'pin' ? (
          <svg width="18" height="18" viewBox="0 0 18 18">
            <path d="M9 16s5-4.6 5-8.6A5 5 0 0 0 4 7.4C4 11.4 9 16 9 16Z" fill="none" stroke="currentColor" strokeWidth="1.5" />
            <circle cx="9" cy="7.4" r="1.8" fill="currentColor" />
          </svg>
        ) : (
          <svg width="18" height="18" viewBox="0 0 18 18">
            <rect x="2" y="4" width="14" height="10" rx="2" fill="none" stroke="currentColor" strokeWidth="1.5" />
            <path d="M2 7.5h14" stroke="currentColor" strokeWidth="1.5" />
          </svg>
        )}
      </span>
      <div className="sp-row__body">
        <div className="sp-row__label">{label}</div>
        {children}
      </div>
    </div>
  );
}

/* ─── Processing ───────────────────────────────────────────────────────── */

function Processing({ order }: { order: ReturnType<typeof useOrder> }) {
  const dispatch = useDispatch();
  const [confirmed, setConfirmed] = useState(0);

  useEffect(() => {
    // ── SIMULATED: Universal Commerce Protocol checkout ──
    // In production: one Shop Pay authorisation is split into a separate
    // order per merchant through UCP. Each merchant's Shopify checkout
    // confirms independently, and tracking flows back into the Shop app.
    const timers: number[] = [];
    const n = order.groups.length;
    for (let i = 1; i <= n; i++) {
      timers.push(window.setTimeout(() => setConfirmed(i), T.processingLeadMs + i * T.merchantStaggerMs));
    }
    timers.push(
      window.setTimeout(() => {
        dispatch({ type: 'purchase' });
        dispatch({ type: 'checkout', stage: 'success' });
      }, T.processingLeadMs + n * T.merchantStaggerMs + T.afterConfirmedMs),
    );
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, []);

  return (
    <motion.div className="sheet__body sheet__body--center" {...fade}>
      <div className="proc">
        <div className="proc__title">{copy.processingTitle}</div>
        <div className="sp-group proc__list">
          {order.groups.map((g, i) => {
            const done = i < confirmed;
            return (
              <div className="proc__row" key={g.merchantId}>
                <div>
                  <div className="proc__name">{merchants[g.merchantId].name}</div>
                  <div className="proc__items">
                    {g.items.length} {g.items.length === 1 ? 'item' : 'items'}
                  </div>
                </div>
                <div className={'proc__status' + (done ? ' is-done' : '')}>
                  <AnimatePresence mode="popLayout" initial={false}>
                    {done ? (
                      <motion.span
                        key="ok"
                        className="proc__ok"
                        initial={{ opacity: 0, scale: 0.6 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ type: 'spring', stiffness: 600, damping: 24 }}
                      >
                        <span className="proc__check">
                          <CheckIcon size={11} color="#fff" />
                        </span>
                        {copy.confirmed}
                      </motion.span>
                    ) : (
                      <motion.span
                        key="spin"
                        className="proc__spinner"
                        exit={{ opacity: 0, scale: 0.6 }}
                        animate={{ rotate: 360 }}
                        transition={{ rotate: { duration: 0.9, repeat: Infinity, ease: 'linear' } }}
                      />
                    )}
                  </AnimatePresence>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}

/* ─── Success ──────────────────────────────────────────────────────────── */

function Success({ orders }: { orders: number }) {
  const dispatch = useDispatch();
  return (
    <motion.div className="sheet__body sheet__body--center" {...fade}>
      <div className="success">
        <motion.div
          className="success__badge"
          initial={{ scale: 0.4, opacity: 0 }}
          animate={{ scale: [0.4, 1.12, 1], opacity: 1 }}
          transition={{ duration: 0.55, times: [0, 0.6, 1], ease: 'easeOut' }}
        >
          <svg width="44" height="44" viewBox="0 0 44 44" aria-hidden>
            <motion.path
              d="M12 22.5l7 7 13-14"
              fill="none"
              stroke="#fff"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ delay: 0.25, duration: 0.4, ease: 'easeOut' }}
            />
          </svg>
        </motion.div>
        <h2 className="success__title">{copy.successTitle}</h2>
        <p className="success__line">{fill(copy.successLine, orders)}</p>
      </div>
      <div className="sheet__footer sheet__footer--stack">
        <motion.button className="btn btn--primary btn--lg" whileTap={{ scale: 0.98 }} onClick={() => dispatch({ type: 'seePurchaseInDressUp' })}>
          {copy.seeInDressUp}
        </motion.button>
        <motion.button className="btn btn--secondary btn--lg" whileTap={{ scale: 0.98 }} onClick={() => dispatch({ type: 'checkout', stage: 'closed' })}>
          {copy.done}
        </motion.button>
      </div>
    </motion.div>
  );
}
