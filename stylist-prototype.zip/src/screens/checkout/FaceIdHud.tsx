import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { checkoutCopy as copy, checkoutTimings as T } from '../../data/demo';

/** iOS-style Face ID confirmation: the glyph scans, then turns into a
 *  checkmark with a small haptic-style pulse. */
export function FaceIdHud() {
  const [done, setDone] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(() => setDone(true), T.faceIdScanMs);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <motion.div
      className="faceid"
      role="status"
      aria-live="assertive"
      aria-label={done ? 'Face ID confirmed' : 'Confirm with Face ID'}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: done ? [1, 1.08, 1] : 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: done ? 0.35 : 0.2 }}
    >
      <div className="faceid__glyph">
        <AnimatePresence mode="wait" initial={false}>
          {!done ? (
            <motion.svg
              key="face"
              width="64"
              height="64"
              viewBox="0 0 64 64"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1, scale: [1, 0.94, 1] }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ scale: { duration: 0.6, repeat: Infinity, ease: 'easeInOut' }, opacity: { duration: 0.15 } }}
            >
              <g fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 18V10a6 6 0 0 1 6-6h8M46 4h8a6 6 0 0 1 6 6v8M60 46v8a6 6 0 0 1-6 6h-8M18 60h-8a6 6 0 0 1-6-6v-8" />
                <path d="M21 23v5M43 23v5" />
                <path d="M32 23v13h-3" />
                <path d="M23 44c5 4 13 4 18 0" />
              </g>
            </motion.svg>
          ) : (
            <motion.svg
              key="check"
              width="64"
              height="64"
              viewBox="0 0 64 64"
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: 'spring', stiffness: 500, damping: 22 }}
            >
              <circle cx="32" cy="32" r="28" fill="none" stroke="currentColor" strokeWidth="3.2" />
              <motion.path
                d="M20 33l8 8 16-17"
                fill="none"
                stroke="currentColor"
                strokeWidth="3.6"
                strokeLinecap="round"
                strokeLinejoin="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.3, ease: 'easeOut' }}
              />
            </motion.svg>
          )}
        </AnimatePresence>
      </div>
      <div className="faceid__label">{copy.faceId}</div>
    </motion.div>
  );
}
