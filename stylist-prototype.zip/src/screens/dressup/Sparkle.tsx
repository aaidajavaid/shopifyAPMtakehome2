import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useEffect, useState } from 'react';

/* A short, tasteful burst for looks scoring 90%+. Fixed particle layout
 * (no randomness) so every demo run looks the same. Never blocks taps. */

const COLORS = ['#D9A441', '#B5654A', '#3E8A5C', '#E9A6A0', '#D9A441', '#F2C76E'];
const PARTICLES = Array.from({ length: 16 }, (_, i) => {
  const angle = (i / 16) * Math.PI * 2 + (i % 2 ? 0.18 : 0);
  const dist = 78 + (i % 3) * 26;
  return {
    x: Math.cos(angle) * dist,
    y: Math.sin(angle) * dist * 0.85,
    size: i % 3 === 0 ? 12 : 8,
    color: COLORS[i % COLORS.length],
    delay: (i % 4) * 0.03,
    rotate: (i % 2 ? 1 : -1) * 90,
  };
});

export function Sparkle({ trigger }: { trigger: number }) {
  const reduce = useReducedMotion();
  const [shown, setShown] = useState(0);

  useEffect(() => {
    if (!trigger || reduce) return;
    setShown(trigger);
    const t = window.setTimeout(() => setShown(0), 1100);
    return () => window.clearTimeout(t);
  }, [trigger, reduce]);

  return (
    <div className="sparkle" aria-hidden>
      <AnimatePresence>
        {shown > 0 &&
          PARTICLES.map((p, i) => (
            <motion.svg
              key={`${shown}-${i}`}
              width={p.size}
              height={p.size}
              viewBox="0 0 10 10"
              className="sparkle__p"
              initial={{ x: 0, y: 0, scale: 0, opacity: 1, rotate: 0 }}
              animate={{ x: p.x, y: p.y, scale: [0, 1.2, 0.9], opacity: [1, 1, 0], rotate: p.rotate }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.9, delay: p.delay, ease: [0.16, 1, 0.3, 1] }}
            >
              <path d="M5 0l1.3 3.7L10 5 6.3 6.3 5 10 3.7 6.3 0 5l3.7-1.3z" fill={p.color} />
            </motion.svg>
          ))}
      </AnimatePresence>
    </div>
  );
}
