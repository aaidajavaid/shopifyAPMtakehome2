import { AnimatePresence, motion, type Variants } from 'framer-motion';
import { useId } from 'react';
import { topOptions, type BottomId, type Look, type OuterId, type TopId } from '../../data/demo';

/* ============================================================================
 * Jane's avatar. An original flat illustration built from separate layers
 * that all share one 200 × 430 coordinate system, so any garment lines up
 * with any other:
 *
 *   body → bottoms → tops → outerwear → shoes → belt
 *
 * Tops end at the waist (y≈199) over the high-rise bottoms (y≈184) and the
 * belt sits on top, which reads as a neat tuck.
 * ========================================================================== */

export const AVATAR_VIEWBOX = '0 0 200 430';

const SKIN = '#E3AE8C';
const SKIN_SHADE = '#CC906E';
const HAIR = '#3A2820';
const HAIR_HI = '#56392C';
const INK = '#2B2622';

/* ─── Body ─────────────────────────────────────────────────────────────── */

export function BodyLayer() {
  return (
    <g>
      {/* Hair, back */}
      <path d="M71 62 Q66 28 100 26 Q134 28 129 62 Q132 82 130 94 Q127 104 117 102 Q112 100 113 94 L114 72 L86 72 L87 94 Q88 100 83 102 Q73 104 70 94 Q68 82 71 62 Z" fill={HAIR} />

      {/* Arms */}
      <path d="M72 106 Q61 110 59 124 L53 180 L53 232 L68 232 L70 182 L77 138 Z" fill={SKIN} />
      <path d="M128 106 Q139 110 141 124 L147 180 L147 232 L132 232 L130 182 L123 138 Z" fill={SKIN} />
      {/* Hands */}
      <path d="M53 229 Q50 245 55 252 Q60 257 65 251 Q69 243 68 229 Z" fill={SKIN} />
      <path d="M147 229 Q150 245 145 252 Q140 257 135 251 Q131 243 132 229 Z" fill={SKIN} />

      {/* Torso */}
      <path d="M92 98 L72 106 L77 138 L80 190 L73 222 L127 222 L120 190 L123 138 L128 106 L108 98 Z" fill={SKIN} />

      {/* Legs */}
      <path d="M75 220 L100 220 L99 240 L95 320 L92 400 L81 400 L78.5 320 L75 242 Z" fill={SKIN} />
      <path d="M125 220 L100 220 L101 240 L105 320 L108 400 L119 400 L121.5 320 L125 242 Z" fill={SKIN} />
      <ellipse cx="85" cy="405" rx="11" ry="5" fill={SKIN} />
      <ellipse cx="115" cy="405" rx="11" ry="5" fill={SKIN} />

      {/* Neck */}
      <path d="M93 82 L107 82 L108 102 Q100 107 92 102 Z" fill={SKIN} />
      <path d="M93 86 Q100 94 107 86 L107 90 Q100 97 93 90 Z" fill={SKIN_SHADE} opacity="0.55" />

      {/* Head */}
      <ellipse cx="74.5" cy="66" rx="4" ry="6" fill={SKIN_SHADE} />
      <ellipse cx="125.5" cy="66" rx="4" ry="6" fill={SKIN_SHADE} />
      <ellipse cx="100" cy="62" rx="25.5" ry="29" fill={SKIN} />

      {/* Face */}
      <circle cx="85" cy="74" r="4.6" fill="#EE8E7C" opacity="0.32" />
      <circle cx="115" cy="74" r="4.6" fill="#EE8E7C" opacity="0.32" />
      <path d="M84 56 Q89 53.5 94 55.5" fill="none" stroke={HAIR} strokeWidth="1.6" strokeLinecap="round" />
      <path d="M106 55.5 Q111 53.5 116 56" fill="none" stroke={HAIR} strokeWidth="1.6" strokeLinecap="round" />
      <ellipse cx="89.5" cy="65" rx="2.5" ry="3.3" fill={INK} />
      <ellipse cx="110.5" cy="65" rx="2.5" ry="3.3" fill={INK} />
      <circle cx="90.4" cy="63.8" r="0.9" fill="#fff" />
      <circle cx="111.4" cy="63.8" r="0.9" fill="#fff" />
      <path d="M86.6 62.6 L85 61.3 M113.4 62.6 L115 61.3" stroke={INK} strokeWidth="1.1" strokeLinecap="round" />
      <path d="M100.5 68 Q102.5 73 99.5 74.2" fill="none" stroke={SKIN_SHADE} strokeWidth="1.4" strokeLinecap="round" />
      <path d="M94.5 80 Q100 84.5 105.5 80" fill="none" stroke="#A0503F" strokeWidth="1.7" strokeLinecap="round" />

      {/* Hair, front: side-swept fringe from a right part */}
      <path d="M74 66 Q71 34 100 30 Q126 29 128.5 56 L127 66 Q124 48 111 41 Q99 52 82 56 Q77 60 74 66 Z" fill={HAIR} />
      <path d="M86 44 Q97 36 110 38" fill="none" stroke={HAIR_HI} strokeWidth="2" strokeLinecap="round" opacity="0.8" />
    </g>
  );
}

/* ─── Bottoms ──────────────────────────────────────────────────────────── */

export function BottomLayer({ id }: { id: BottomId }) {
  if (id === 'drape') {
    // Way-High Drape Pant: high rise, wide fluid leg, black
    return (
      <g>
        <path d="M78 184 L122 184 L126 222 L135 300 L139 404 L104 404 L101 252 L100 242 L99 252 L96 404 L61 404 L65 300 L74 222 Z" fill="#262426" />
        <path d="M78.5 192 L121.5 192" stroke="#3B383B" strokeWidth="1.2" />
        <path d="M87 200 L82 403 M113 200 L118 403" stroke="#3B383B" strokeWidth="1.1" opacity="0.9" />
        <path d="M100 192 L100 222" stroke="#3B383B" strokeWidth="1.1" />
      </g>
    );
  }
  if (id === 'jeans') {
    // Dark-wash straight jeans, ankle length
    return (
      <g>
        <path d="M79 186 L121 186 L127 224 L124 300 L121 396 L104 396 L101 252 L100 244 L99 252 L96 396 L79 396 L76 300 L73 224 Z" fill="#2E3D57" />
        <g fill="none" stroke="#C9A15B" strokeWidth="0.9" strokeDasharray="2 1.8">
          <path d="M79.5 194 L120.5 194" />
          <path d="M100 194 L100 226 Q97 228 95 224" />
          <path d="M76 206 Q84 208 87 198 M124 206 Q116 208 113 198" />
          <path d="M79.5 390 L95.5 390 M104.5 390 L120.5 390" />
        </g>
        <path d="M88 230 L86 390 M112 230 L114 390" stroke="#3A4B68" strokeWidth="1" opacity="0.8" />
      </g>
    );
  }
  // Black yoga pants: fitted, follows the leg
  return (
    <g>
      <path d="M80 186 L120 186 L128 224 L124 300 L121 398 L107.5 398 L103 252 L100 242 L97 252 L92.5 398 L79 398 L76 300 L72 224 Z" fill="#1F1E21" />
      <path d="M79.5 197 L120.5 197" stroke="#38363A" strokeWidth="1.4" />
      <path d="M86 236 L86 392 M114 236 L114 392" stroke="#2E2C30" strokeWidth="1" />
    </g>
  );
}

/* ─── Tops ─────────────────────────────────────────────────────────────── */

export function TopLayer({ id }: { id: TopId }) {
  const uid = useId().replace(/:/g, '');

  if (id === 'striped') {
    const d =
      'M90 97 L70 105 Q59 109 57 123 L51 180 L51 234 L70 234 L72 182 L78 140 L80 190 L80 199 L120 199 L120 190 L122 140 L128 182 L130 234 L149 234 L149 180 L143 123 Q141 109 130 105 L110 97 L100 110 Z';
    return (
      <g>
        <defs>
          <clipPath id={`s${uid}`}>
            <path d={d} />
          </clipPath>
        </defs>
        <path d={d} fill="#F5F7FB" stroke="#D5DCE8" strokeWidth="0.8" />
        <g clipPath={`url(#s${uid})`} stroke="#6A86AE" strokeWidth="1.3" opacity="0.8">
          {Array.from({ length: 26 }, (_, i) => (
            <line key={i} x1={50 + i * 4} y1="90" x2={50 + i * 4} y2="240" />
          ))}
          <rect x="49" y="226" width="23" height="9" fill="#F5F7FB" stroke="none" />
          <rect x="128" y="226" width="23" height="9" fill="#F5F7FB" stroke="none" />
        </g>
        <path d="M90 96 L100 110 L94 116 L86 100 Z" fill="#FFFFFF" stroke="#C9D2E0" strokeWidth="0.8" />
        <path d="M110 96 L100 110 L106 116 L114 100 Z" fill="#FFFFFF" stroke="#C9D2E0" strokeWidth="0.8" />
        <path d="M100 112 L100 199" stroke="#C9D2E0" strokeWidth="1" />
        {[126, 144, 162, 180].map((y) => (
          <circle key={y} cx="102.2" cy={y} r="1.1" fill="#9FB0C8" />
        ))}
      </g>
    );
  }

  if (id === 'tee') {
    return (
      <g>
        <path
          d="M91 97 L70 105 Q59 109 57 123 L54 148 L72 151 L77 138 L80 190 L80 199 L120 199 L120 190 L123 138 L128 151 L146 148 L143 123 Q141 109 130 105 L109 97 Q100 107 91 97 Z"
          fill="#FFFFFF"
          stroke="#E3DDD4"
          strokeWidth="0.9"
        />
        <path d="M91 97 Q100 107 109 97" fill="none" stroke="#DCD5CB" strokeWidth="1.6" />
        <path d="M58 140 L73 143 M142 140 L127 143" stroke="#ECE7DF" strokeWidth="1.2" />
      </g>
    );
  }

  if (id === 'knit') {
    return (
      <g>
        <path
          d="M89 96 L69 104 Q57 108 55 122 L49 180 L50 234 L71 234 L73 182 L78 142 L79 190 L79 201 L121 201 L121 190 L122 142 L127 182 L129 234 L150 234 L151 180 L145 122 Q143 108 131 104 L111 96 Q100 104 89 96 Z"
          fill="#EFE5D3"
          stroke="#DCCDB4"
          strokeWidth="0.9"
        />
        <g stroke="#DCCDB4" strokeWidth="1">
          {[52, 56, 60, 64, 68].map((x) => (
            <line key={`l${x}`} x1={x} y1="226" x2={x} y2="234" />
          ))}
          {[132, 136, 140, 144, 148].map((x) => (
            <line key={`r${x}`} x1={x} y1="226" x2={x} y2="234" />
          ))}
          <path d="M50.5 226 L70.5 226 M129.5 226 L149.5 226" />
        </g>
        <path d="M89 96 Q100 104 111 96" fill="none" stroke="#D6C6AA" strokeWidth="2.6" />
        <g stroke="#E2D5BE" strokeWidth="1" opacity="0.9">
          {[88, 96, 104, 112].map((x) => (
            <line key={x} x1={x} y1="112" x2={x} y2="196" />
          ))}
        </g>
      </g>
    );
  }

  // Satin blouse, ivory, soft V-neck
  return (
    <g>
      <path
        d="M90 97 L70 105 Q58 109 56 123 L50 180 L49 228 Q60 236 71 228 L73 182 L78 140 L80 190 L80 199 L120 199 L120 190 L122 140 L127 182 L129 228 Q140 236 151 228 L150 180 L144 123 Q142 109 130 105 L110 97 L100 124 Z"
        fill="#F3EBDD"
        stroke="#DED1BC"
        strokeWidth="0.9"
      />
      <path d="M90 97 L100 124 L110 97" fill="none" stroke="#DED1BC" strokeWidth="1.2" strokeLinejoin="round" />
      <path d="M62 128 Q58 160 58 200 M138 128 Q142 160 142 200" stroke="#FFFFFF" strokeWidth="2" opacity="0.7" fill="none" strokeLinecap="round" />
      <path d="M88 140 Q90 170 87 196 M112 140 Q110 170 113 196" stroke="#E4D8C4" strokeWidth="1.1" fill="none" />
    </g>
  );
}

/* ─── Outerwear ────────────────────────────────────────────────────────── */

export function OuterLayer({ id }: { id: OuterId }) {
  if (id !== 'blazer') return null;
  // Tailored Crepe Blazer: cropped, black, worn open
  const fill = '#262426';
  const lapel = '#343134';
  const seam = '#3F3B3F';
  return (
    <g>
      <path d="M89 96 L68 103 Q57 108 55 122 L49 180 L48 236 L71 236 L73 182 L77 142 L76 214 Q85 217 93 214 L97 170 Z" fill={fill} />
      <path d="M111 96 L132 103 Q143 108 145 122 L151 180 L152 236 L129 236 L127 182 L123 142 L124 214 Q115 217 107 214 L103 170 Z" fill={fill} />
      <path d="M89 96 L97 170 L90 152 L84 128 L80 120 L86 114 Z" fill={lapel} stroke={seam} strokeWidth="0.7" />
      <path d="M111 96 L103 170 L110 152 L116 128 L120 120 L114 114 Z" fill={lapel} stroke={seam} strokeWidth="0.7" />
      <path d="M78.5 196 L90 196 M110 196 L121.5 196" stroke={seam} strokeWidth="1.3" strokeLinecap="round" />
      <path d="M73 182 L71 236 M127 182 L129 236" stroke={seam} strokeWidth="0.8" />
      <path d="M48.5 228 L70.5 228 M129.5 228 L151.5 228" stroke={seam} strokeWidth="0.9" />
    </g>
  );
}

/* ─── Shoes ────────────────────────────────────────────────────────────── */

export function ShoesLayer() {
  // Selma Ballet Flat, black leather
  return (
    <g>
      <path d="M73 405 Q74 399 84 399 Q93 399 96 402 L97 407 Q95 412 84 412 Q72 412 73 405 Z" fill="#262426" />
      <path d="M127 405 Q126 399 116 399 Q107 399 104 402 L103 407 Q105 412 116 412 Q128 412 127 405 Z" fill="#262426" />
      <ellipse cx="88" cy="402" rx="6" ry="2" fill={SKIN} />
      <ellipse cx="112" cy="402" rx="6" ry="2" fill={SKIN} />
      <path d="M75 407 Q80 409 86 408 M125 407 Q120 409 114 408" stroke="#3E3B3E" strokeWidth="0.9" fill="none" strokeLinecap="round" />
    </g>
  );
}

/* ─── Belt ─────────────────────────────────────────────────────────────── */

/** With an open jacket on, only the centre of the belt shows. */
export function BeltLayer({ underJacket }: { underJacket: boolean }) {
  const uid = useId().replace(/:/g, '');
  return (
    <g clipPath={underJacket ? `url(#b${uid})` : undefined}>
      <defs>
        <clipPath id={`b${uid}`}>
          <rect x="93.5" y="180" width="13" height="24" />
        </clipPath>
      </defs>
      <path d="M77 186 Q100 190 123 186 L123 194 Q100 198 77 194 Z" fill="#262426" />
      <rect x="95" y="185.8" width="10" height="10.4" rx="1.6" fill="none" stroke="#C8C2B8" strokeWidth="1.8" />
      <path d="M96.5 191 L104 191" stroke="#C8C2B8" strokeWidth="1.2" strokeLinecap="round" />
    </g>
  );
}

/* ─── Shadow ───────────────────────────────────────────────────────────── */

export function GroundShadow() {
  return <ellipse cx="100" cy="414" rx="44" ry="6" fill="rgba(60,45,30,0.12)" />;
}

const slide: Variants = {
  enter: (d: number) => ({ x: 46 * d, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (d: number) => ({ x: -46 * d, opacity: 0 }),
};
const slideSpring = { x: { type: 'spring', stiffness: 380, damping: 28 }, opacity: { duration: 0.18 } } as const;

export interface PieceLabel {
  slot: 'outer' | 'top' | 'belt' | 'bottom' | 'shoes';
  name: string;
  stylist: boolean;
}

interface AvatarProps {
  look: Look;
  /** Which part changed and in which direction; omit for a static avatar. */
  swap?: { part: 'top' | 'bottom' | 'all'; dir: 1 | -1 };
  label?: string;
  /** Callout labels for each piece, drawn in the space beside her. */
  labels?: PieceLabel[];
}

/* Where each callout sits, and the point on the garment it points to. */
const CALLOUTS: Record<PieceLabel['slot'], { side: 'left' | 'right'; y: number; ax: number; ay: number }> = {
  outer: { side: 'right', y: 124, ax: 133, ay: 128 },
  top: { side: 'left', y: 150, ax: 84, ay: 152 },
  belt: { side: 'right', y: 188, ax: 110, ay: 191 },
  bottom: { side: 'left', y: 288, ax: 88, ay: 298 },
  shoes: { side: 'right', y: 404, ax: 118, ay: 405 },
};
const LABEL_VIEWBOX = '-100 0 400 430';

/** A single short label; the dot shows where the piece comes from
 *  (filled clay = From Stylist, hollow grey = her closet). */
function Callout({ l, hasJacket }: { l: PieceLabel; hasJacket: boolean }) {
  const c = CALLOUTS[l.slot];
  // With a jacket on, the top shows in the open front, so point there.
  const ax = l.slot === 'top' && hasJacket ? 100 : c.ax;
  const left = c.side === 'left';
  const tx = left ? 40 : 160;
  return (
    <motion.g initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
      <path d={`M${left ? tx + 4 : tx - 4} ${c.y} L${ax} ${c.ay}`} stroke="#C4B8A9" strokeWidth="0.9" fill="none" />
      <circle
        cx={ax}
        cy={c.ay}
        r="3.2"
        fill={l.stylist ? '#B5654A' : '#FFFDFA'}
        stroke={l.stylist ? '#FFFDFA' : '#9B9188'}
        strokeWidth="1.6"
      />
      <text
        x={tx}
        y={c.y + 5}
        textAnchor={left ? 'end' : 'start'}
        fontFamily="inherit"
        fontSize="15"
        fontWeight="600"
        letterSpacing="-0.2"
        fill="#2B2622"
      >
        {l.name}
      </text>
    </motion.g>
  );
}

/** Full avatar for a look. Tops (with any jacket) and bottoms slide in and
 *  out as their own layers; the body, shoes and belt stay put. */
export function Avatar({ look, swap, label = "Jane's avatar", labels }: AvatarProps) {
  const opt = topOptions.find((o) => o.id === look.top)!;
  const topDir = swap?.part === 'top' ? swap.dir : 0;
  const bottomDir = swap?.part === 'bottom' ? swap.dir : 0;

  if (!swap) {
    return (
      <svg viewBox={AVATAR_VIEWBOX} width="100%" height="100%" role="img" aria-label={label}>
        <GroundShadow />
        <BodyLayer />
        <BottomLayer id={look.bottom} />
        <TopLayer id={opt.top} />
        <OuterLayer id={opt.outer} />
        <ShoesLayer />
        <BeltLayer underJacket={opt.outer !== null} />
      </svg>
    );
  }

  return (
    <svg
      viewBox={labels ? LABEL_VIEWBOX : AVATAR_VIEWBOX}
      width="100%"
      height="100%"
      role="img"
      aria-label={label}
      style={{ overflow: 'visible' }}
    >
      <GroundShadow />
      <BodyLayer />
      <AnimatePresence initial={false} custom={bottomDir}>
        <motion.g key={look.bottom} custom={bottomDir} variants={slide} initial="enter" animate="center" exit="exit" transition={slideSpring}>
          <BottomLayer id={look.bottom} />
        </motion.g>
      </AnimatePresence>
      <AnimatePresence initial={false} custom={topDir}>
        <motion.g key={look.top} custom={topDir} variants={slide} initial="enter" animate="center" exit="exit" transition={slideSpring}>
          <TopLayer id={opt.top} />
          <OuterLayer id={opt.outer} />
        </motion.g>
      </AnimatePresence>
      <ShoesLayer />
      <BeltLayer underJacket={opt.outer !== null} />
      {labels && (
        <g className="callouts">
          <AnimatePresence initial={false}>
            {labels.map((l) => (
              <Callout key={l.slot + l.name} l={l} hasJacket={opt.outer !== null} />
            ))}
          </AnimatePresence>
        </g>
      )}
    </svg>
  );
}
