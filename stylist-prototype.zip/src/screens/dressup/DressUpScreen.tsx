import { AnimatePresence, motion, type PanInfo } from 'framer-motion';
import { useEffect, useState } from 'react';
import {
  closetItems,
  dressUpCopy as copy,
  dressUpGarments as G,
  looksProgress,
  products,
  sparkleThreshold,
  styleScores,
  stylistLook,
  topOptions,
  type Garment,
  type Look,
} from '../../data/demo';
import { useAppState, useDispatch } from '../../state/store';
import { ItemImage } from '../../components/ItemImage';
import { OccasionTag, formatPrice, scoreBand } from '../../components/ui';
import { ResetTitle } from '../../shell/ResetTitle';
import { ScoreBadge } from '../stylist/ConfidenceCard';
import { Avatar, type PieceLabel } from './Avatar';
import { Sparkle } from './Sparkle';
import './dressup.css';

const lookKey = (l: Look) => `${l.top}|${l.bottom}`;

function garmentsFor(look: Look) {
  const opt = topOptions.find((o) => o.id === look.top)!;
  return {
    opt,
    outer: opt.outer ? G.outer[opt.outer] : null,
    top: G.tops[opt.top],
    bottom: G.bottoms[look.bottom],
  };
}

function SourceChip({ source }: { source: 'stylist' | 'closet' }) {
  return (
    <span className={'srcchip srcchip--' + source}>{source === 'stylist' ? copy.fromStylist : copy.inCloset}</span>
  );
}

export function DressUpScreen() {
  const { outfitReady, dressUpHighlight, look, swap, savedLooks, looksCreated, bag, tab, purchased } = useAppState();
  const showBackbar = outfitReady && purchased.length === 0;
  const dispatch = useDispatch();
  const [burst, setBurst] = useState(0);
  const [hasSwiped, setHasSwiped] = useState(false);

  const key = lookKey(look);
  const score = styleScores[key];
  const { outer, top, bottom } = garmentsFor(look);
  const saved = savedLooks.includes(key);
  const band = scoreBand(score.score);

  // Sparkle for 90%+ looks, every time one appears on screen.
  useEffect(() => {
    if (swap.n > 0 && tab === 'dressup' && score.score >= sparkleThreshold) setBurst(swap.n);
    // Only when the look changes.
  }, [swap.n]); // eslint-disable-line react-hooks/exhaustive-deps

  const cycle = (part: 'top' | 'bottom', dir: 1 | -1) => {
    setHasSwiped(true);
    dispatch({ type: 'cycle', part, dir });
  };

  const onPan = (part: 'top' | 'bottom') => (_: unknown, info: PanInfo) => {
    const { x, y } = info.offset;
    if (Math.abs(x) < 36 || Math.abs(x) < Math.abs(y)) return;
    cycle(part, x < 0 ? 1 : -1);
  };

  const labels: PieceLabel[] = [
    ...(outer ? [{ slot: 'outer' as const, name: outer.short, stylist: outer.source === 'stylist' }] : []),
    { slot: 'top', name: top.short, stylist: top.source === 'stylist' },
    { slot: 'belt', name: G.belt.short, stylist: G.belt.source === 'stylist' },
    { slot: 'bottom', name: bottom.short, stylist: bottom.source === 'stylist' },
    { slot: 'shoes', name: G.shoes.short, stylist: G.shoes.source === 'stylist' },
  ];

  const wearing: Garment[] = [...(outer ? [outer] : []), top, bottom, G.belt, G.shoes];
  const bagItems = products.filter((p) => bag.includes(p.id));
  const subtotal = bagItems.reduce((s, p) => s + p.price, 0);

  const save = () => {
    if (saved) return;
    dispatch({ type: 'saveLook' });
    dispatch({ type: 'toast', text: copy.savedToast });
  };

  return (
    <div className="dressup">
      <div className={'scroll tabscroll' + (showBackbar ? ' has-backbar' : '')}>
        <header className="largetitle dressup__head">
          <ResetTitle>
            <h1>{copy.title}</h1>
          </ResetTitle>
          {outfitReady && (
            <motion.button className="pillbtn" whileTap={{ scale: 0.95 }} onClick={() => dispatch({ type: 'setLook', look: stylistLook })}>
              <svg width="12" height="12" viewBox="0 0 10 10" aria-hidden>
                <path d="M5 0l1.3 3.7L10 5 6.3 6.3 5 10 3.7 6.3 0 5l3.7-1.3z" fill="currentColor" />
              </svg>
              {copy.stylistLookButton}
            </motion.button>
          )}
        </header>

        {/* Stage: every piece is labelled beside her. Swipe her top or
            bottom half, or use the arrows on her, to change pieces. */}
        <div className="stage">
          <div className="stage__glow" aria-hidden />
          <motion.div className="swipezone swipezone--top" onPanEnd={onPan('top')} aria-hidden />
          <motion.div className="swipezone swipezone--bottom" onPanEnd={onPan('bottom')} aria-hidden />
          <div className="stage__box">
            <Avatar look={look} swap={swap} labels={labels} />
            <ArrowBtn side="left" row="top" label="Previous top" onClick={() => cycle('top', -1)} />
            <ArrowBtn side="right" row="top" label="Next top" onClick={() => cycle('top', 1)} />
            <ArrowBtn side="left" row="bottom" label="Previous bottoms" onClick={() => cycle('bottom', -1)} />
            <ArrowBtn side="right" row="bottom" label="Next bottoms" onClick={() => cycle('bottom', 1)} />
          </div>
          <motion.button
            className={'heartbtn' + (saved ? ' is-saved' : '')}
            aria-label={saved ? 'Look saved' : copy.saveLook}
            aria-pressed={saved}
            whileTap={saved ? undefined : { scale: 0.85 }}
            onClick={save}
          >
            <motion.svg
              key={saved ? 'on' : 'off'}
              width="20"
              height="20"
              viewBox="0 0 16 16"
              aria-hidden
              initial={saved ? { scale: 0.4 } : false}
              animate={{ scale: [saved ? 0.4 : 1, saved ? 1.25 : 1, 1] }}
              transition={{ duration: 0.35 }}
            >
              <path
                d="M8 13.6S2 10.2 2 6.1A3.1 3.1 0 0 1 8 4.6a3.1 3.1 0 0 1 6 1.5c0 4.1-6 7.5-6 7.5Z"
                fill={saved ? 'currentColor' : 'none'}
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
            </motion.svg>
          </motion.button>
          {/* Bottom line: the swipe hint first, then a tiny dot legend. */}
          <AnimatePresence mode="wait" initial={false}>
            {!hasSwiped ? (
              <motion.div key="hint" className="stage__hint" exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
                {copy.swipeHint}
              </motion.div>
            ) : (
              <motion.div
                key="legend"
                className="stage__hint stage__legend"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.25 }}
              >
                <span className="legend__dot legend__dot--stylist" />
                {copy.legendStylist}
                <span className="legend__dot legend__dot--closet" />
                {copy.legendCloset}
              </motion.div>
            )}
          </AnimatePresence>
          <Sparkle trigger={burst} />
        </div>

        {/* Style Match, in the same visual language as Closet match */}
        <section className="match" aria-label={copy.styleMatch}>
          <ScoreBadge value={score.score} label={copy.styleMatch} className="matchbadge--inline" />
          <div className="match__body">
            <AnimatePresence mode="popLayout" initial={false}>
              <motion.div
                key={key}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ type: 'spring', stiffness: 500, damping: 34 }}
              >
                <div className="match__top">
                  <OccasionTag occasion={score.occasion} />
                </div>
                <div className="match__headline">
                  <span style={{ color: band.color }}>{score.score}%</span> {score.label}
                </div>
                <div className="match__reason">{score.reason}</div>
              </motion.div>
            </AnimatePresence>
          </div>
        </section>

        <section className="wearing" aria-label={copy.wearingLabel}>
          <div className="section-label">{copy.wearingLabel}</div>
          <div className="wearing__list">
            {wearing.map((g) => {
              const product = products.find((p) => p.id === g.refId);
              const closet = closetItems.find((c) => c.id === g.refId);
              const trying = outfitReady && g.refId === dressUpHighlight;
              return (
                <div key={g.refId} className={'wrow' + (trying ? ' is-trying' : '')}>
                  {product ? (
                    <ItemImage folder="products" file={product.image} placeholder={product.placeholder} alt="" className="wrow__img" inset={10} />
                  ) : closet ? (
                    <ItemImage folder="closet" file={closet.image} placeholder={closet.placeholder} alt="" className="wrow__img" inset={10} />
                  ) : null}
                  <div className="wrow__body">
                    <div className="wrow__name">{g.name}</div>
                    {trying && <div className="wrow__trying">{copy.tryingOn}</div>}
                  </div>
                  <SourceChip source={g.source} />
                </div>
              );
            })}
          </div>
        </section>

        <section className="mylooks" aria-label={copy.myLooks}>
          <div className="section-label mylooks__label">
            <span>{copy.myLooks}</span>
            <span className="mylooks__progress">
              {looksCreated} of {looksProgress.goal} {looksProgress.label}
            </span>
          </div>
          {savedLooks.length === 0 ? (
            <div className="mylooks__empty">{copy.myLooksEmpty}</div>
          ) : (
            <div className="mylooks__row">
              <AnimatePresence initial={false}>
                {savedLooks.map((k) => {
                  const [t, b] = k.split('|') as [Look['top'], Look['bottom']];
                  const s = styleScores[k];
                  return (
                    <motion.button
                      key={k}
                      layout
                      className={'lookthumb' + (k === key ? ' is-current' : '')}
                      initial={{ opacity: 0, scale: 0.7 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ type: 'spring', stiffness: 420, damping: 26 }}
                      aria-label={`Saved look, ${s.score}% ${s.label}`}
                      onClick={() => dispatch({ type: 'setLook', look: { top: t, bottom: b } })}
                    >
                      <div className="lookthumb__fig">
                        <Avatar look={{ top: t, bottom: b }} label="" />
                      </div>
                      <span className="lookthumb__score" style={{ color: scoreBand(s.score).color }}>
                        {s.score}%
                      </span>
                    </motion.button>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </section>
      </div>

      {showBackbar && (
        <div className="backbar">
          <motion.button className="backbar__btn" whileTap={{ scale: 0.97 }} onClick={() => dispatch({ type: 'backToBag' })}>
            <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden>
              <path
                d="M4 6.5h10l-.8 8.2a1.5 1.5 0 0 1-1.5 1.3H6.3a1.5 1.5 0 0 1-1.5-1.3Z"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinejoin="round"
              />
              <path d="M6.5 6.5V5a2.5 2.5 0 0 1 5 0v1.5" fill="none" stroke="currentColor" strokeWidth="1.6" />
            </svg>
            <span>{copy.backToBag}</span>
            <span className="backbar__meta">
              {bagItems.length} {bagItems.length === 1 ? 'item' : 'items'} · {formatPrice(subtotal)}
            </span>
          </motion.button>
        </div>
      )}
    </div>
  );
}

function ArrowBtn({
  side,
  row,
  label,
  onClick,
}: {
  side: 'left' | 'right';
  row: 'top' | 'bottom';
  label: string;
  onClick: () => void;
}) {
  return (
    <motion.button className={`arrow arrow--${side} arrow--${row}`} aria-label={label} whileTap={{ scale: 0.86 }} onClick={onClick}>
      <svg width="13" height="13" viewBox="0 0 14 14" aria-hidden>
        <path
          d={side === 'left' ? 'M8.8 2.5 4.3 7l4.5 4.5' : 'M5.2 2.5 9.7 7l-4.5 4.5'}
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </motion.button>
  );
}
