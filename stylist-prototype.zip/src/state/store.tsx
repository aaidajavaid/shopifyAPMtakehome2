import { createContext, useContext, useReducer, type Dispatch, type ReactNode } from 'react';
import {
  bottomOptions,
  closetLook,
  looksProgress,
  productLooks,
  products,
  stylistLook,
  topOptions,
  type Look,
} from '../data/demo';

/* App state lives in memory only. A page refresh or the hidden long-press
 * reset brings everything back to the opening state. */

export type Tab = 'stylist' | 'dressup' | 'closet';

export type ChatEvent =
  | { id: string; kind: 'agent'; text: string }
  | { id: string; kind: 'user'; text: string; anchor?: boolean }
  | { id: string; kind: 'thinking' }
  | { id: string; kind: 'steps'; done: number }
  | { id: string; kind: 'outfit' };

export type ChipSet = 'initial' | 'retry' | null;

export interface State {
  tab: Tab;
  chat: ChatEvent[];
  chips: ChipSet;
  /** True once the agent has produced the work outfit. */
  outfitReady: boolean;
  /** Product ids currently in the bag. All four start in it. */
  bag: string[];
  /** Only one Confidence Card can be open at a time. */
  openConfidenceId: string | null;
  /** Item highlighted when arriving in Dress Up from a product card. */
  dressUpHighlight: string | null;
  /** Bumped every time Dress Up loads a look from elsewhere. */
  dressUpRequest: number;
  /** What the avatar is wearing right now. */
  look: Look;
  /** Last change, so the right garment slides in from the right side. */
  swap: { part: 'top' | 'bottom' | 'all'; dir: 1 | -1; n: number };
  /** Saved looks, as "top|bottom" keys, newest first. */
  savedLooks: string[];
  looksCreated: number;
  /** Bumped when "Back to bag" should scroll Stylist to the bag. */
  bagFocus: number;
  toast: { id: number; text: string } | null;
  /** Closet: item sheet and Stylist-picks toggle. */
  closetSheet: string | null;
  showPicks: boolean;
  /** Shop Pay sheet flow. */
  checkout: 'closed' | 'review' | 'faceid' | 'processing' | 'success';
  /** Product ids bought; they join the closet. */
  purchased: string[];
}

export const initialState: State = {
  tab: 'stylist',
  chat: [],
  chips: null,
  outfitReady: false,
  bag: products.map((p) => p.id),
  openConfidenceId: null,
  dressUpHighlight: null,
  dressUpRequest: 0,
  look: closetLook,
  swap: { part: 'all', dir: 1, n: 0 },
  savedLooks: [],
  looksCreated: looksProgress.start,
  bagFocus: 0,
  toast: null,
  closetSheet: null,
  showPicks: true,
  checkout: 'closed',
  purchased: [],
};

export type Action =
  | { type: 'setTab'; tab: Tab }
  | { type: 'pushChat'; event: ChatEvent }
  | { type: 'replaceChat'; id: string; event: ChatEvent }
  | { type: 'stepsDone'; id: string; done: number }
  | { type: 'setChips'; chips: ChipSet }
  | { type: 'outfitReady' }
  | { type: 'toggleBag'; id: string }
  | { type: 'toggleConfidence'; id: string }
  | { type: 'viewInDressUp'; productId: string }
  | { type: 'backToBag' }
  | { type: 'cycle'; part: 'top' | 'bottom'; dir: 1 | -1 }
  | { type: 'setLook'; look: Look }
  | { type: 'saveLook' }
  | { type: 'checkout'; stage: State['checkout'] }
  | { type: 'purchase' }
  | { type: 'closetSheet'; id: string | null }
  | { type: 'togglePicks' }
  | { type: 'styleInDressUp'; itemId: string; look: Look }
  | { type: 'seePurchaseInDressUp' }
  | { type: 'toast'; text: string }
  | { type: 'clearToast'; id: number };

let toastSeq = 0;

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'setTab':
      return { ...state, tab: action.tab };
    case 'pushChat':
      // Ignore duplicates (e.g. the greeting firing twice in development).
      if (state.chat.some((e) => e.id === action.event.id)) return state;
      return { ...state, chat: [...state.chat, action.event] };
    case 'replaceChat':
      return { ...state, chat: state.chat.map((e) => (e.id === action.id ? action.event : e)) };
    case 'stepsDone':
      return {
        ...state,
        chat: state.chat.map((e) => (e.id === action.id && e.kind === 'steps' ? { ...e, done: action.done } : e)),
      };
    case 'setChips':
      return { ...state, chips: action.chips };
    case 'outfitReady':
      return { ...state, outfitReady: true };
    case 'toggleBag':
      if (state.purchased.length) return state;
      return {
        ...state,
        bag: state.bag.includes(action.id)
          ? state.bag.filter((id) => id !== action.id)
          : // keep the original product order
            products.map((p) => p.id).filter((id) => id === action.id || state.bag.includes(id)),
      };
    case 'toggleConfidence':
      return { ...state, openConfidenceId: state.openConfidenceId === action.id ? null : action.id };
    case 'viewInDressUp':
      return {
        ...state,
        tab: 'dressup',
        dressUpHighlight: action.productId,
        dressUpRequest: state.dressUpRequest + 1,
        look: productLooks[action.productId] ?? stylistLook,
        swap: { part: 'all', dir: 1, n: state.swap.n + 1 },
      };
    case 'cycle': {
      const look = { ...state.look };
      if (action.part === 'top') {
        const i = topOptions.findIndex((o) => o.id === look.top);
        look.top = topOptions[(i + action.dir + topOptions.length) % topOptions.length].id;
      } else {
        const i = bottomOptions.indexOf(look.bottom);
        look.bottom = bottomOptions[(i + action.dir + bottomOptions.length) % bottomOptions.length];
      }
      return { ...state, look, swap: { part: action.part, dir: action.dir, n: state.swap.n + 1 } };
    }
    case 'setLook':
      return { ...state, look: action.look, swap: { part: 'all', dir: 1, n: state.swap.n + 1 } };
    case 'saveLook': {
      const key = `${state.look.top}|${state.look.bottom}`;
      if (state.savedLooks.includes(key)) return state;
      return {
        ...state,
        savedLooks: [key, ...state.savedLooks],
        looksCreated: Math.min(looksProgress.goal, state.looksCreated + 1),
      };
    }
    case 'backToBag':
      return { ...state, tab: 'stylist', closetSheet: null, openConfidenceId: null, bagFocus: state.bagFocus + 1 };
    case 'checkout':
      return { ...state, checkout: action.stage };
    case 'purchase':
      return { ...state, purchased: [...state.bag] };
    case 'seePurchaseInDressUp':
      return {
        ...state,
        closetSheet: null,
  showPicks: true,
  checkout: 'closed',
        tab: 'dressup',
        dressUpHighlight: null,
        look: stylistLook,
        swap: { part: 'all', dir: 1, n: state.swap.n + 1 },
      };
    case 'closetSheet':
      return { ...state, closetSheet: action.id };
    case 'togglePicks':
      return { ...state, showPicks: !state.showPicks };
    case 'styleInDressUp':
      return {
        ...state,
        closetSheet: null,
        tab: 'dressup',
        dressUpHighlight: action.itemId,
        dressUpRequest: state.dressUpRequest + 1,
        look: action.look,
        swap: { part: 'all', dir: 1, n: state.swap.n + 1 },
      };
    case 'toast':
      return { ...state, toast: { id: ++toastSeq, text: action.text } };
    case 'clearToast':
      return state.toast?.id === action.id ? { ...state, toast: null } : state;
  }
}

const StateCtx = createContext<State>(initialState);
const DispatchCtx = createContext<Dispatch<Action>>(() => {});

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <StateCtx.Provider value={state}>
      <DispatchCtx.Provider value={dispatch}>{children}</DispatchCtx.Provider>
    </StateCtx.Provider>
  );
}

export const useAppState = () => useContext(StateCtx);
export const useDispatch = () => useContext(DispatchCtx);

/* Demo reset: the root re-keys the whole app, which clears state and
 * cancels every pending timer. */
export const ResetCtx = createContext<() => void>(() => {});
export const useReset = () => useContext(ResetCtx);
