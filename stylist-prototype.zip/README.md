# Stylist

A clickable iPhone prototype of an AI shopping agent that answers one question: *"Does this work for my life and my closet?"*

Front end only. There are no accounts, payments or network calls, and all data is sample data. Once loaded, it works offline.

---

## Run it on your computer

You need **Node.js** (version 18 or newer) once. Get the "LTS" installer from [nodejs.org](https://nodejs.org) and run it.

Then open **Terminal**, go to this folder, and run these two commands:

```bash
npm install
```

```bash
npm run dev
```

Terminal prints a local address, usually **http://localhost:5173**. Open it in Chrome or Safari. On a computer, the app appears inside an iPhone frame.

To stop it, press `Ctrl + C` in Terminal.

**Tip:** `npm run dev` also prints a "Network" address (like `http://192.168.1.20:5173`). If your phone is on the same Wi-Fi, open that address on your phone to try it full-screen.

---

## Put it on your phone for the demo (Vercel, free)

1. Create a free account at [vercel.com](https://vercel.com). Signing in with GitHub is easiest.
2. **Option A, no Git needed:** in Terminal, in this folder, run:
   ```bash
   npx vercel
   ```
   Answer the questions (the defaults are fine). Vercel detects Vite by itself. When it finishes, run `npx vercel --prod` to get your permanent link.
3. **Option B, with GitHub:** push this folder to a GitHub repository. In Vercel, click **Add New → Project**, pick the repository and click **Deploy**. Nothing needs configuring.
4. Open the link on your iPhone in **Safari**, tap **Share → Add to Home Screen**, then launch it from the home-screen icon. It opens full-screen like a native app.

---

## The 3-minute demo

1. **Stylist:** tap **Build me an outfit for work**. Three agent steps tick off, then "Here are 5 new pieces that create 24 new outfits with what's already in your closet," followed by 5 product cards with closet-match rings (85 / 77 / 92 / 85 / 92).
2. Tap **Why this works** on a card to show the reason, pairings and social proof, then collapse it.
3. Tap **Try on** on the blazer. Dress Up shows it with her own striped shirt and jeans (86%).
4. Tap the lower right arrow (or swipe her legs): yoga pants score **31%** with a helpful reason. Tap again: the drape pant scores **94%** with a sparkle. Tap the **heart** to save the look.
5. **Closet:** the 5 Stylist picks show in place with dashed outlines and "In your bag" tags. Tap the category chips, then tap a piece to open its sheet.
6. Tap **Back to bag** (Dress Up) or **View in bag** (Closet), then **Buy with Shop Pay → Pay now**. Face ID, 4 merchant confirmations, success.
7. Back in **Closet**, the 5 pieces are solid with green **New** tags.

**Reset the demo:** hold the **9:41 clock** for 1 second (desktop frame). On a real phone, hold the screen title (**Stylist**, **Dress Up** or **Closet**) for 1 second. Refreshing the page also resets everything. Every run is identical: no randomness, fixed timings.

The other three suggestion chips each get a short, in-character reply that leads back to the work outfit, so a judge who taps one never hits a dead end.

---

## Editing content

Everything you might want to change lives in **`src/data/demo.ts`**:

- **Products:** names, prices, merchants, "View product" links, occasion tags, closet-match counts, reasons, social proof.
- **Closet:** the 13 items, their tags, "worn in" counts and pairings.
- **Stylist copy:** greeting, chip replies, agent steps, and the opening line (the "24 new outfits" number is `newOutfitsCount`).
- **Dress Up:** the tops and bottoms you can swipe through, each piece's short label, and the **Style Match table** with a hand-written score, occasion and reason for all 21 top-and-bottom combinations.
- **Checkout:** sample contact, card, tax rate and all checkout copy.
- **Timings:** typing speed, agent steps, Face ID and merchant confirmations.

**Closet match** is set as a count (e.g. `closetMatches: 12`). The percentage is calculated against the 13-item closet, so "92%" and "12 of 13" always agree.

### Adding real photos

Drop image files into:

- `public/images/products/`: `blouse.png`, `pant.png`, `blazer.png`, `belt.png`, `flats.png`
- `public/images/closet/`: the filenames listed for each closet item in `demo.ts` (e.g. `striped-shirt.png`)

PNGs with a transparent or light background look best. Until a file exists, the app shows a flat illustration of that item in its colour.

---

## Where the "backend" would be

Every simulated backend moment is marked in the code with a comment block starting `// ── SIMULATED:`. Search the project for `SIMULATED:` to find them:

- **Shopify Catalog API**: finding products across merchants (`src/screens/stylist/StylistScreen.tsx`)
- **Closet compatibility model**: scoring each product against the closet (`src/screens/stylist/StylistScreen.tsx`)
- **Universal Commerce Protocol checkout**: one checkout across 4 merchants (`src/screens/checkout/ShopPaySheet.tsx`)

---

## Tech

Vite, React and TypeScript, with Framer Motion for animation. State is kept in memory only (no localStorage). Animations respect the iOS "Reduce Motion" setting.
